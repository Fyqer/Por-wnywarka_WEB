//***************************************************
// Program z paragrafu   8.18 (str 222)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 

#include <iostream>
using namespace std ;

#include <cstdlib>          // dla atof

/******************************************************/
int main(int argc, char * argv[])
{
     cout << "Wydruk parametrow wywolania :\n" ;

     for(int i = 0 ; i < argc ; i++)
     {
          cout << "Parametr nr "<< i
               << " to string: " << argv[i]
               << endl ;
     }

     /* --- zamienimy string na liczbe ---*/

     float x ;
     x = atof(argv[2]);
     x = x + 4;
     cout << "x =  " << x << endl ;


}





/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------
#include <cstdlib>          // dla atof

------------------------------------------------------

int main()

-------------------------------------------------------


************************************************************/
