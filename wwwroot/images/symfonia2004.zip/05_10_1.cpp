//***************************************************
// Program z paragrafu  5.10.1 (str 96)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

int liczba ;                                        //
void fff(void) ;
/****************************************************/
int   main()
{
int i ;
     liczba = 10 ;                                   //
     i = 4 ;
     cout << "Wartosci: liczba = " << liczba
          << " i = " <<  i ;
     fff() ;                                        //

}
/****************************************************/
void fff(void) {
     int x ;                                         //
     x = 5 ;
     liczba -- ;                                     //
     // i = 4 ;               // blad !

     cout << " sumka = " << (x + liczba) ;
}
/****************************************************/



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()


************************************************************/
