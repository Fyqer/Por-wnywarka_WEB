//***************************************************
// Program z paragrafu   7.4 (str 142)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;


#include <cstring>

int main()
{
char tekst[] = { "Uwaga, tarcza zostala przepalona !"} ;
char komunikat[120] ;

     strcpy(komunikat, tekst);
     cout << komunikat << endl ;

     strncpy(komunikat, "1234567890abcdef" , 9 );      //

     cout << komunikat ;

     strcpy(komunikat, "--A ku-ku --!" ) ;
     cout << "\nNa koniec : "
          << komunikat << endl ;
}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
#include <cstring>

------------------------------------------------------
int main()


************************************************************/
