//***************************************************
// Program z paragrafu   8.7.2 (str 163)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 

#include <iostream>
using namespace std ;

//****************************************************
int main()
{
int *wi ;
float *wf ;
int tabint[10] = { 0,1,2,3,4,5,6,7,8,9 };               //
float tabflo[10] ;                                        //
               // ustawienie wskaznika
     wf = &tabflo[0] ;                                   //

               // zaladowanie tablicy float wartosciami poczatkow.

     for(int i = 0  ; i < 10 ; i++)
     {
          *(wf++)  = i / 10.0 ;             // tablica float

     }

     cout << "Tresc tablic na poczatku\n" ;

     wi = tabint;
     wf = tabflo ;
     for(int k = 0   ; k < 10      ; k++)
     {
          cout << k << ") \t" << *wi << "\t\t\t\t"
               << *wf << endl ;                         //
          wi ++ ;                                        //
          wf ++ ;
     }

     // nowe ustawienie wskaznik�w

     wi = &tabint[5] ;                                   //
     wf = tabflo + 2 ;           // czyli wf = &tabflo[2] ;

     // wpisanie do tablic  kilku nowych wartosci
     for(int m = 0 ; m < 4 ; m++){
          *(wi++) = -222 ;                              //
          *(wf++) = -777.5 ;
     }

     cout << "Tresc tablic po wstawieniu nowych wartosci\n";
     wi = tabint ;
     wf = tabflo ;
     for(int p = 0 ; p < 10 ; p++){
          cout << "tabint[" << p << "] =  "
               << *(wi++)
               << "   \t\ttabflo[" << p << "] =  "
               << *(wf++)
               << endl ;
     }

}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------

int main()

------------------------------------------------------
     wi = tabint;        // wyjete powyzej for
     wf = tabflo ;       // wyjete powyzej for
     for(int i = 0   ; i < 10      ; i++)  <--- Dopisane "int"

W mysl nowych zasad, poprzednia definicja obiektu "i"
juz nie jest wazna, tamten obiekt "i" istnial tylko na uzytek
poprzedniej petli for (i potem przestal istniec).

------------------------------------------------------
  // wpisanie do tablic  kilku nowych wartosci
     for(int i = 0 ; i < 4 ; i++){

Dopisane "int", powod jak wyzej
Niestety VC++ nie jest tu zgodny ze standardem
i musialem zmienic takze nazwe 
------------------------------------------------------
     for(int i = 0 ; i < 10 ; i++){
Dopisane "int", powod jak wyzej
Niestety VC++ nie jest tu zgodny ze standardem
i musialem zmienic takze nazwe "i"

----------------------------------------------------
Podobnie z wszystkimi tu petlami for, oczywiscie
to tylko dlatego ze VC++ nie respektuje standardu
------------------------------------------------------

************************************************************/
