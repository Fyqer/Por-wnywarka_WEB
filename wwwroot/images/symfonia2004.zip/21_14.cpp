//***************************************************
// Program z paragrafu   21.14 (str 645)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;
#include <fstream>
/******************************************************/
int main()
{
ofstream osrodek ;                              // etap

     osrodek.open("ksiezyc.tmp") ;              // etap
     osrodek << "misja" ;                       // etap
     osrodek.close();                          // etap
}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <fstream>
------------------------------------------------------
int main()
------------------------------------------------------

************************************************************/


