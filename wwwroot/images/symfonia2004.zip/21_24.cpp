//***************************************************
// Program z paragrafu   21.24 (str 686)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

#include <iomanip>

// PRZESTARZALY
#include <strstream>   // <--- bo uzywamy istrstream

// NOWY SPOSOB
#include <sstream>   // <-- bo  uzywamy istringstream

/*******************************************************/
int main()
{

  cout << "################# Stary sposob ################" << endl;

char schowek[40] = { "7.15 wtorek" } ;



istrstream potok(schowek, sizeof(schowek) );           //


float liczba ;
char wyraz[40] ;



     potok >> liczba >> wyraz ;                         //

     liczba = liczba + 1 ;

     cout << "Na dowod, ze sie udalo :\n"            //
          << "Biezaca wartosc zmiennej liczba = " << liczba
          << "\nnatomiast wyraz brzmi = " << wyraz ;

     // demonstracja mozliwosci pozycjonowania
     potok.clear( potok.rdstate() & ~ios::eofbit) ;//

     potok.seekg(1, ios::beg) ;                       //
     char c ;

     potok.get(c) ;

     cout << "\nwydobyty znak c = " << c << endl ;

     potok.seekg(4, ios::cur) ;
     potok.get(c) ;
     cout << "Czwarty znak dalej to = " << c << endl ;




  cout << "################# Nowy sposob ################" << endl;


string schowek2("7.15 wtorek") ;
istringstream potok2(schowek2 );           //



     potok2 >> liczba >> wyraz ;                         //

     liczba = liczba + 1 ;

     cout << "Na dowod, ze sie udalo :\n"            //
          << "Biezaca wartosc zmiennej liczba = " << liczba
          << "\nnatomiast wyraz brzmi = " << wyraz ;

     // demonstracja mozliwosci pozycjonowania
     potok2.clear( potok.rdstate() & ~ios::eofbit) ;//

     potok2.seekg(1, ios::beg) ;                       //


     potok2.get(c) ;

     cout << "\nwydobyty znak c = " << c << endl ;

     potok2.seekg(4, ios::cur) ;
     potok2.get(c) ;
     cout << "Czwarty znak dalej to = " << c << endl ;



}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <iomanip>
#include <strstream>   // <--- bo uzywamy ostrstream


------------------------------------------------------
Operacje pokazywane tutaj w programie sa tak czeste, ze
wprowadzone sa ulepszenia. Krotko mowiac mozna to zrobic
teraz jeszcze prosciej - z pomoca nieco innej klasy

Aby z tego skorzystac potrzebna jest dyrektywa

#include <sstream>   // <-- bo  uzywamy istringstream
------------------------------------------------------
int main()
------------------------------------------------------



Oprocz starego sposobu, do ktorego nowy standard juz
zniecheca - (choc ciagle akceptuje) pokazuje tu
lepszy sposob - z uzyciem klasy o nazwie ostringstream


  cout << "############## NOWY sposob ##############" << endl;


string schowek2("7.15 wtorek") ;   // <-- NOWY TYP, string
istringstream potok2(schowek2 );           // NOWYA LEPSZA KLASA,



W wypadku tej nowej, lepszej klasy  istringstream
tablica znakowa jest w obiektcie klasy strnig.
O tej klasie w "Syfmonii" nie rozmawialismy, ale
weszla juz na trwale do standardu.

(W nowych wydaniach "Symfonii C++" musi byc na ten
temat obszerny rozdzial).

-------------------------------------------------------

************************************************************/


