//***************************************************
// Program z paragrafu   11.a (str 309)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;

#include <cstring>

//--------------------------
class kwadrat ;                // deklaracja zapowiadajaca

////////////////////////////////////////////////////////
class punkt {
     int  x, y ;
     char nazwa[30] ;
public :
     punkt(int a, int b,char *opis) ;
     void ruch(int n, int m)  { x += n ; y += m ; }
     // ... moze cos jeszcze ...

     friend int sedzia(punkt & p, kwadrat & k) ;   //
} ;
////////////////////////////////////////////////////////
class kwadrat  {
     int  x, y,
          bok ;
     char nazwa[30] ;
public :
     kwadrat(int a, int b, int dd, const char *opis) ;
     // ... moze cos jeszcze ...

     friend int sedzia (punkt & p, kwadrat & k) ;      //
} ;
////////////////////////////////////////////////////////
punkt::punkt(int a, int b,char *opis)     // konstruktor
{
     x = a ; y = b ;
     strcpy(nazwa, opis) ;
}
/******************************************************/
kwadrat::kwadrat(int a, int b, int dd, const char *opis)
                                             // konstruktor
{      x = a ; y = b ;
     bok = dd ;

     if(opis)       strcpy(nazwa, opis) ;
     else         nazwa[0] = 0 ; // pusty string

}
/******************************************************/
// z ta funkcja przyjaznia sie obie klasy
int sedzia (punkt & pt, kwadrat & kw)                    //

{
     if( (pt.x >= kw.x)  &&  (pt.x <= (kw.x + kw.bok) )
          &&
           (pt.y >= kw.y)  &&  (pt.y <= (kw.y + kw.bok) )
       )
     {
          cout << pt.nazwa << " lezy na tle "
               << kw.nazwa << endl ;
          return 1 ;
     }else {
          cout << "AUT ! " << pt.nazwa
               << " jest na zewnatrz "
               << kw.nazwa << endl ;
          return 0 ;
     }
}
/******************************************************/
int main()
{
     kwadrat     bo(10,10, 40, "boiska") ;
     punkt     pi( 20, 20, "pilka");

     sedzia(pi, bo );                                   //
     cout << "kopiemy pilke !\n" ;
     while(sedzia(pi, bo)){
          pi.ruch(20,20);
     }


}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <cstring>

------------------------------------------------------

kwadrat::kwadrat(int a, int b, int dd, const char *opis)
                                             // konstruktor
w deklaracji i definicji tego konstruktora dodany jest
przydomek "const"
Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*

------------------------------------------------------

     if(opis)       strcpy(nazwa, opis) ;
     else         nazwa[0] = 0 ; // pusty string

 dodane zostalo sprawdzenie
czy wskaznik do stringu nie pokazuje czasem na adres 0 (NULL).
Gdyby tak bylo, to funkcja strcpy spowodowalaby blad pamieci.
Zatem najpierw to sprawdzamy, a jesli ta, to do tablicy nazwa
wpisujemy 0 do zerowego elementu, co odpowiada pustemu stringowi

------------------------------------------------------
int main()

------------------------------------------------------



-------------------------------------------------------

************************************************************/
