//***************************************************
// Program z paragrafu   8.16 b)  (str 199)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;



char * strcpy(char *cel, char *zrodlo) ;
/******************************************************/
int main()
{
char poziom[] = { "Poziom szumu w normie" } ;
char komunikat[80] ;

     strcpy(komunikat,  poziom) ;                    //
     cout << poziom  << endl ;
     cout << komunikat  << endl ;

}
/******************************************************/
char * strcpy(char *cel, char *zrodlo)             //
{
char *poczatek = cel ;                           //

     while(  (*(cel++) = *(zrodlo++))  );             //
     return poczatek ;                              //
}
/******************************************************/




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------

int main()

------------------------------------------------------
 while((*(cel++) = *(zrodlo++)));

 Powyzej dodana zostala jeszcze jedna para nawiasow
 Dzieki takiemu zapisowi
        while ((a=b))
 dajemy do zrozumienia kompilatorowi ze naprawde chodzi nam
 o przypisanie a nie porownanie. Kompilator widzac ten
 dodatkowy nawias nie wypisuje juz ostrzezenia

************************************************************/
