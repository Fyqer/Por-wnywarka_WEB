//***************************************************
// Program z paragrafu   7.5 (str  145)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream>
using namespace std ;

void wczytaj_dane() ;
/***************************************************/
int main()
{
long widmo[4][2048] ;
long suma ;
int i ;

     wczytaj_dane() ;                  // tajemnicza funkcja, ktora
                    // wczyta z dysku cztery zestawy wynikow
                    // pomiarowych i dane te umiesci w tablicy widmo

     cout  << "Jaki przedzial widma ma byc integrowany ?\n"
           << "podaj dwie liczby : " ;

     int pocz, koniec ;
     cin >> pocz >> koniec ;

                         // ---- petla po 4 r�znych probkach
     for(int pomiar = 0 ; pomiar < 4 ; pomiar ++)   //

     {
          suma = 0 ;

                         // ---- petla integrujaca  dane jednej probki
          for(i = pocz ; i <= koniec ; i++)               //
          {
               suma += widmo[pomiar][i] ;                 //
          }

          cout << "\nW probce "<< pomiar
               << " miedzy kanalami "
               << pocz << " a " << koniec <<" jest "
               << suma << " zliczen"  ;                //
     }                      // koniec petli po 4 pomiarach

}
/***************************************************/
void wczytaj_dane()
{
     //... wczytywanie danych z dysku
}





/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------

void wczytaj_dane() ;

W deklaracji a potem takze w definicji typ zwracany
okreslony jest jako "void"
------------------------------------------------------

int main()

------------------------------------------------------



************************************************************/
