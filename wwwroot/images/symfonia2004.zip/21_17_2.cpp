//***************************************************
// Program z paragrafu   21.17.2 (str 664)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

#include <fstream>
/******************************************************/
int main()
{
char tekst[] = {
      "Coz, wedlug Ben-Alego,\n"
      "czarnomistrza Krakowa\n"
      "nie jest to nic wielkiego\n"
      "dorozke zaczarowac."} ;

  // Otwieram istniejacy plik i go zeruje,
  // lub jesli go nie ma - tworze go 
  fstream strum("wiersz.tmp", ios_base::trunc | ios_base::in | ios_base::out);
  if(!strum)
  {
    cout << "Blad otwarcia pliku " << endl;
    return -1 ;
  }

  strum << tekst ;

  // pozycjonowanie kursora pisania na literze 25
  strum.seekp(25) ;
  strum << "ABCDE" ;

  // pozycjonowanie kursora pisania na znaku 6 od konca
  strum.seekp(-6, ios_base::end) ;
  strum << "X" ;
}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <fstream>

------------------------------------------------------
int main()
------------------------------------------------------
Wszystkie 3 wystapienia kwalifikatora
        ios::
zamienione zostaly na
        ios_base::

------------------------------------------------------

  // Otwieram istniejacy plik i go zeruje,
  // lub jesli go nie ma - tworze go 
  fstream strum("wiersz.tmp", ios_base::trunc |   // <-- dodany ten tryb
							ios_base::in | 
							ios_base::out);
    
------------------------------------------------------	
if(!strum)
  {
    cout << "Blad otwarcia pliku " << endl;
    return -1 ;
  }
Gdyby pliku nie udalo sie otworzyc lub stworzyc od nowe,
pojawi sie informacja o bledzie.

************************************************************/


