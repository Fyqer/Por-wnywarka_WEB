//***************************************************
// Program z paragrafu   8.7.4 (str 170)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

//****************************************************
int main()
{
  int tablica[5] ;
  int *wsk_czer,  *wsk_ziel ;
  int i ;

  wsk_czer = &tablica[3] ;
  cout <<
    "Mamy piecioelementowa tablice \n"
    "Wskaznik czerwony pokazuje na "
    "element o indeksie 3\n"
    "Na ktory element ma pokazywac "
    "wskaznik zielony ? (0-4) : ";

  cin >> i ;
  if(i < 0 || i > 4)
    cout << "\nNie ma takiego elementu w tej tablicy !" ;
  else
    {
      wsk_ziel = &tablica[i] ;
      cout <<
	"\nZ przeprowadzonego porownania wskaznikow\n"
	"czerwonego z zielonym wynika, ze : \n" ;

      // wlasciwa akcja por�wnania
      if(wsk_czer > wsk_ziel)
	{
	  cout <<
	    "zielony pokazuje na element "
	    "blizej poczatku tablicy" ;
	}
      else if(wsk_czer < wsk_ziel)
	{
	  cout <<
	    "zielony pokazuje na element "
	    "o wyzszym indeksie" ;
	}
      else
	{
	  // czyli: wsk_czer == wsk_ziel
	  cout <<
                  "zielony i czerwony pokazuja "
	    "na to samo\n" ;
	}
    }

}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------

int main()


************************************************************/
