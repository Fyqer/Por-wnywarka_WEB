//***************************************************
// Program z paragrafu  1.1 (str 6)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream>
using namespace std ;

int main()
{
     cout << "Witamy na pokladzie" ;
}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()

************************************************************/
