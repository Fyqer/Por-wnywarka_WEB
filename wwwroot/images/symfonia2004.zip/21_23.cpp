//***************************************************
// Program z paragrafu   21.23 (str 680)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

#include <iomanip>
#include <strstream>   // <--- bo uzywamy ostrstream

#include <sstream>   // <-- bo  uzywamy ostringstream
/*******************************************************/
int main()
{
int nr_silnika = 4 ;
float temperat = 156.7123 ;


 cout << "################### Stary sposob ##################" << endl;
char komunikat[80] ;

// ta klasa juz wyszla z mody, jest przestarzala
ostrstream strumyk(komunikat, sizeof(komunikat) );     //


// a teraz wlasciwe wypisanie

  strumyk << "Awaria silnika "<< setw(2) << nr_silnika
       << ", temperatura oleju " << setprecision(2)
       << temperat << " stopni C \n" ;                 //

  strumyk << "Musisz cos zrobic !!!\n" << ends ;      //

  cout << "Aby sie przekonac czy w tablicy "
           "znalazl sie\nrzeczywiscie zadany tekst "
           "wypisujemy jej tresc\nna ekran \n" ;
  cout <<           "*******************************************\n"
       << komunikat
       << "*******************************************\n";

  strumyk.seekp(8, ios_base::beg);                        //

  strumyk << "XYZ" ;
  cout << "Po zabawie z pozycjonowaniem :\n"
       << komunikat ;



  cout << "\n##################### NOWY STYL ######################"
  << endl;


  ostringstream strumyk2;     //

// a teraz wlasciwe wypisanie

  strumyk2 << "Awaria silnika "<< setw(2) << nr_silnika
       << ", temperatura oleju " << setprecision(2)
       << temperat << " stopni C \n" ;                 //

       if(!strumyk2) cout << "jakis blad "<< endl;

  strumyk2 << "Musisz cos zrobic !!!\n" << ends ;      //

  cout << "Aby sie przekonac czy w tablicy "
           "znalazl sie\nrzeczywiscie zadany tekst "
           "wypisujemy jej tresc\nna ekran \n" ;
  cout <<           "*******************************************\n"
       << strumyk2.str()
       << "*******************************************\n";

  strumyk2.seekp(8, ios_base::beg);                        //

  strumyk2 << "XYZ" ;
  cout << "Po zabawie z pozycjonowaniem :\n"
       << strumyk2.str() ;



}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <iomanip>
#include <strstream>   // <--- bo uzywamy ostrstream


------------------------------------------------------
Operacje pokazywane tutaj w programie sa tak czeste, ze
wprowadzone sa ulepszenia. Krotko mowiac mozna to zrobic
teraz jeszcze prosciej - z pomoca nieco innej klasy

Aby z tego skorzystac potrzebna jest dyrektywa

#include <sstream>   // <-- bo  uzywamy ostringstream
------------------------------------------------------
int main()
------------------------------------------------------



Oprocz starego sposobu, do ktorego nowy standard juz
zniecheca - (choc ciagle akceptuje) pokazuje tu
leszy sposob - z uzyciem klasy o nazwie ostringstream


  ostringstream strumyk2;     // <-- definicja tego NOWEGO strumienia

// a teraz wlasciwe wypisanie, (bez zmian)

  strumyk2 << "Awaria silnika "<< setw(2) << nr_silnika
       << ", temperatura oleju " << setprecision(2)
       << temperat << " stopni C \n" ;                 //

  strumyk2 << "Musisz cos zrobic !!!\n" << ends ;      //

  cout << "Aby sie przekonac czy w tablicy "
           "znalazl sie\nrzeczywiscie zadany tekst "
           "wypisujemy jej tresc\nna ekran \n" ;
  cout <<           "*******************************************\n"
       << strumyk2.str()  //   <---- TAK Z TEGO KORZYSTAMY
       << "*******************************************\n";

  strumyk2.seekp(8, ios_base::beg);                        //

  strumyk2 << "XYZ" ;
  cout << "Po zabawie z pozycjonowaniem :\n"
       << strumyk2.str() ;  //   <---- TAK Z TEGO KORZYSTAMY



UWAGA:  jak widzisz jest tu uzycie funkcji str()
Przypomina to podobne zagadnienie paragraf 21.23.1
("Mechanizm Automatycznej Rezerwacji Miejsca").
To tylo pozor, bo dzialanie tej funkcji nie ma nic
wspolnego z omawianym tam "przejsciem na emerture".
Ta funkcja po prostu zwraca kopie stringu, a potem
na oryginalnym stringu dalej mozna i tak pracowac.
Co zreszta widac w naszym programie - funkcje te
wywolujemy przeciez dwukrotnie.



-------------------------------------------------------

-----------------------------------------------------------
Wszystkie wystapienia kwalifikatora ios:: zostaly
zamienione na ios_base::

************************************************************/


