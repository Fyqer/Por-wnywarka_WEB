//***************************************************
// Program z paragrafu   21.11.3 (str 629)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;
#include <iomanip>

ostream & tem(ostream & strum)
{
     strum << setprecision(1) << setiosflags(ios::showpos)
           << setiosflags(ios::fixed)
           << resetiosflags(ios::scientific) ;
     return strum ;
}
/*******************************************************/
ostream & wys(ostream & strum)
{
     strum << resetiosflags(ios::showpos) ;
     return strum ;
}
/*******************************************************/
ostream & ges(ostream & strum)
{
     strum << resetiosflags(ios::fixed)
           << setiosflags(ios::scientific)
           << setprecision(4) ;
     return strum ;
}
/*******************************************************/
int main()
{
float t = 20.47,
      g = 0.09273 ;
int   w = 3000 ;

cout << " temperatura= " << tem << t
     << " wysokosc = "<< wys << w
     << " gestosc = "<< ges << g
     << endl ;
}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
#include <iomanip>

------------------------------------------------------
int main()
------------------------------------------------------

************************************************************/


