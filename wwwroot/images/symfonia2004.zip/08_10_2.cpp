//***************************************************
// Program z paragrafu  8.10.2 (str 187)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 

#include <iostream>
using namespace std ;

//*****************************************************
int main()
{
int *cze, *zol ;                    // def. 2 wskaznik�w


     cze = new int ;               // tworzymy obiekt A

     zol = new int ;               // tworzymy obiekt B

     *cze = 100 ;               // ladujemy 100 do obiektu A

     *zol = 200 ;               // ladujemy 200 do obiektu B

     cout << " Po wpisaniu : Na czerwonym = "<< *cze
          << " Na zoltym = "   << * zol  << endl ;
     cze = zol ;                     // Niefortunna linijka !


     cout << " Po przelozeniu - Na czerwonym = "<< *cze
          << " Na zoltym = "   << * zol  << endl ;

     *cze = 5 ;
     *zol = 1 ;                                           //

     cout << " Jakis wpis - Na czerwonym = "<< *cze
          << " Na zoltym = "   << * zol  << endl ;

     delete zol ;                                        //
     // delete cze ;               // Horror !


}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------

int main()



************************************************************/
