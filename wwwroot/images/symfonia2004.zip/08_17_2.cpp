//***************************************************
// Program z paragrafu   8.17.2 (str 216)
//***************************************************

// Uwaga: Program ten musial zostac dramatycznie zmieniony


// Sprawdzony na Linuksie,   kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


/*------------------------------------------------------
Program zostal napisany z wykorzystaniem niektorych
funkcji bibliotecznych charakterystycznych dla kompilatora
          Borland C++ 3.1

W czasach, gdy go pisalem, kompilator ten byl bardzo powszechny,
dlatego uzylem w nim funkcji, ktorych w standardzie nie ma.
Chodzi o funkcje pracujace z klawiatura i glosniczkiem komputera.
Obecnie kompilator BC++ 3.1 jest juz prawie nie uzywany,.
Oczywiscie moglbym poszukac odpowiednikow tych funkcji
w najbardziej popularnych kompilatorach. Tymczasem zalozenie
"Symfonii C++" jest inne. Ma ona opisywac zagadnienia
wspolne dla wszystkich kompilatorow, czyli krotko mowiac
standardowy C++.

Poniewaz newralgiczne funkcje nie sa osia tego zagadnienia
dlatego z nich tu zrezygnowalem.
Zdefiniowalem w programie wlasne wersje tych funkcji.
Ich dzialanie jest nieco inne, ale nie o to tu glownie chodzi.

------------------------------------------------------*/

#include <iostream>
using namespace std ;

#include <cctype>               // dla tolower
//#include <conio.h>               // dla kbhit
//#include <dos.h>               // dla sound, nosound, delay

int pytanie(const char *pyt,void (*wskaznik_funkcji)() ) ;//

void muzyczka() ;                                 //

void wiatraczek() ;
void kurs() ;

int kbhit();
//*****************************************************
void delay(int ile)
{
        for(int i = 0 ; i < ile *100 ; i++) ;
}
/******************************************************/
int main()
{
int i ;
     cout << "Samolot gotowy \n" ;
     while(1)
     {
          i = pytanie("Czy mam juz startowac ?",
                                        muzyczka ) ;  //
          if(i)
          {
               cout << "Uwaga, startujemy !\n" ;
               break ;
          }
          else
          {
               cout << "nie to czekam...\n " ;
          }
     }
     cout << "Lecimy...\n" ;
     switch(pytanie("Czy dodac gazu ? ",wiatraczek) )//

     {
          case 1 :
               cout << "Zrobione !\n" ;
               break ;
          case 0 :
               cout << "Nie zmieniam !\n" ;
               break ;
     }
     pytanie("dobrze sie leci, prawda ? ", kurs);  //

}
/******************************************************/
int pytanie(const char *pyt, void (*wskaznik_funkcji)() )
{
char c ;
     cout << pyt << endl;
     while(1)
     {
          (*wskaznik_funkcji)() ;                    //

          cin >> c ;
          switch(tolower(c) )
          {
               case 't' :
                    return 1;
               case 'n' :
                    return 0 ;
               default :
                    cout<< "odpowiedz 't' lub 'n' \n" ;
                    break ;
          }
     }
}
/******************************************************/
void muzyczka()
{
        cout <<"\a\aZagrala muzyczka..., ale teraz odpowiedz: " ;
}
/******************************************************/
void wiatraczek()                              //
{
char t[] = {      '|', '\\',
               '-', '/' };
int i ;

     while(!kbhit() )
     {
          cout << "        " << t[(i++) % 4] << "\r";
          delay(200);
     }
     cout <<"Wiatraczek sie pokrecil..., ale teraz odpowiedz: " ;
}
/******************************************************/
void kurs()
{
int i ;
     while(!kbhit() )
     {
          cout << "kurs " << (239 + ((i++) % 4))
                           << "...\r";
          delay(200);
     }
     cout <<"Pokazywalem kurs, ale teraz odpowiedz: " ;
}


//*****************************************************
int kbhit()
{
        static int licznik ;

        licznik++ ;
        if(! (licznik % 10000) )
                return 1 ; // oznacza ze wcisnieto klawisz
        else
                return 0 ; // oznacza ze nie wcisnieto

}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------
#include <cctype>               // dla tolower

------------------------------------------------------

//#include <conio.h>               // dla kbhit  //<---- usuniete
//#include <dos.h>               // dla sound, nosound, delay //<---- usuniete

Usuniete oba naglowki, bo w programie definiujemy swoje wlasne wersje tych
funkcji.

----------------------------------------------------
Usunalem wywolanie funkcji sound, nosound
Zastepuje je
 cout << "\a" ;
czyli wyslanie znaku "alarm" do strumienia cout
co objawia sie sygnalem dzwiekowym glosniczka ("beep")
----------------------------------------------------
void delay(int ile)
{
        for(int i = 0 ; i < ile *100 ; i++) ;
}
Imitacja fukcji delay (opoznienie)


----------------------------------------------------

int main()



------------------------------------------------------
int pytanie(const char *pyt,void (*wskaznik_funkcji)() ) ;// <-- dodane "const"

W deklaracji oraz definicji funkcji dodane jest slowo "const"

Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*
-------------------------------------------------------

Nowa definicja funkcji kbhit to oczywiscie wielkie oszustwo

int kbhit()
{
        static int licznik ;

        licznik++ ;
        if(! (licznik % 10000) )
                return 1 ; // oznacza ze wcisnieto klawisz
        else
                return 0 ; // oznacza ze nie wcisnieto

}
Jak widac, funkcja ta raz na 10000 wywolan odpowiada
zwracajac 1, a w pozostalych wypadkach odpowiada zwracajac 0

Wszystko dlatego, ze funkcja, ktora sprawdza czy ktos wcisnal
jakis klawisz na klawiaturze, albo czy naprzyklad rownoczesnie
jest wcisniety klawisz Ctrl, lub Num Lock nie jest ujeta w standardzie.
To znaczy rozne kompilatory nazywaja ja inaczej, wymagaja innych
argumentow i inaczej odpowiadajac.
"Inaczej", to znaczy na przyklad zwracajac strukture, na ktorej
skladanikach jest informacja o sytuacji na klawiaturze.
Aby sie niezaleznic od tych wariantow i dac tu program,
ktory sie da skompilowac za pomoca dowolnego kompilatora C++,
musialem zrezygnowac z tych "wodotryskow".
Pamietaj jednak ze sens tego przykladu to: "jak przekazac
funkcji adres innej funkcji, ktora powinna ona sobie wywolac.


************************************************************/
