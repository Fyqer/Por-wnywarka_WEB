//***************************************************
// Program z paragrafu   21.13.3 (str 640)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

/*******************************************************/
int main()
{
char kuferek[10] ;
char skrytka[10] ;

     cout << "Napisz okolo 10 znakow : "  ;

     cin.getline(kuferek, 4);


     if(!cin)
     {
       // usuniecie stanu bledu
       cin.clear(cin.rdstate() & ~ios_base::failbit);
     }



     cin.ignore(2).getline(skrytka, 10);

     cout << "\nW kuferku jest :"<< kuferek
          << ", w skrytce jest :" << skrytka
          << "\na dwa znaki zignorowalem " << endl ;
}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;


------------------------------------------------------
int main()
------------------------------------------------------
!!! Uwaga !!! :
wedlug nowych zasad funkcja getline zachowuje sie odmiennie.

Na skutek takiej instrukcji
  cin.getline(kuferek, 4);
probuje wczytac do tablicy kuferek cala liniie, az do
ogranicznika - w tym wypadku znaku '\n'
Argument 4 mowi funkcji ze tablica kuferek,
moze przyjac maksymalnie 4 znaki (konkretnie 3 znaki
i konczacy NULL).
Jesli jednak wystukamy na klawiaturze wiecej znakow
przyjete zostana trzy, do nich dopisany znak NULL.

ALE UWAGA: strumien informuje ze przyjecie znakow
zostalo przerwane nie przy napotkaniu ogranicznika ('\n')
- (co byloby normalne),
ale przerwanie przyjmowania znaku wyniklo z tego ze
obszar, ktory na to przeznaczylismy (4) okazal sie za maly.
(Funkcja getline przeciez nie wie, ze naprawde tablica kuferek
jest wieksza - 10 elementowa).
To jest raczej powazna sprawa, wiec powinnismy zostac
o tej sytuacji "za malo miejsca" poinformowani.

Jak funkcja informuje nas o niemozliwosci doczytania
do ogranicznika?
Ustawia mianowicie strumien na, ktorym pracowala
w stan "fail" (Niepowodzenie). Dalsze
operacje wczytywnia za pomoca tego strumieniu beda
niemozliwe, chyba ze strumien 'naprawimy.

O stanach bledu strumienia traktowal bedzie jeden z
nastepnych paragrafow 21.15

Te informacje mozemy przyjac do wiadomosci
po czym strumien 'naprawic', czyli zgasic w nim
stan "fail" i kontynuowac prace dalej.
To robi tajemnicza instrukcja

       cin.clear(cin.rdstate() & ~ios::failbit);
Po szczegoly odsylam do paragrafu 21.15

Refleksja: oczywiscie te klopoty wynikly z faktu
ze funkcji getline kazalismy wczytywac okreslona
ilosc znakow. Tymczasem ona jest przeznaczona
do wyczytywania LINII znakow, gdzie "linia" jest
uznawana jako "wszystko az do ogranicznika".

Mysle ze w nowym wydaniu ksiazki nalezy przerobic
ten przyklad tak, by oddawal lepiej istote zastosowania
getline.



-------
Dodany jest framgent

     if(!cin)   // <--- czy strumien jest w stanie bledu
     {
       // usuniecie stanu bledu
       cin.clear(cin.rdstate() & ~ios_base::failbit);  <-- napraw blad failbit
     }

************************************************************/


