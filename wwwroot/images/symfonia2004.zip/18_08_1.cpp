//***************************************************
// Program z paragrafu   18.8.1 (str 438)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;


/////////////////////////////////////////////////////////
class wektorek {
public :
     float x, y, z ;
     // --- konstruktor
     wektorek(float xp = 0, float yp = 0, float zp = 0 )
                    : x(xp), y(yp), z(zp)                  //
     { /* cialo puste */ } ;

     // ... inne funkcje skladowe
} ;
/////////////////////////////////////////////////////////
wektorek operator*(wektorek kopia, float liczba )     //

{
wektorek rezultat ;

     rezultat.x = kopia.x * liczba ;
     rezultat.y = kopia.y * liczba ;
     rezultat.z = kopia.z * liczba ;
     return rezultat ;
}
/*******************************************************/
void pokaz(wektorek www) ;          // deklaracja
/*******************************************************/
int main()
{
wektorek     a(1,1,1) ,
          b(-15, -100, +1) ,
          c ;

          c = a * 6.66 ;                               //
          pokaz(c) ;

          c = b * -1.0 ;
          pokaz(c) ;
}
/*******************************************************/
void pokaz(wektorek www)
{
      cout << " x = " <<  www.x
           << " y = " <<  www.y
           << " z = " <<  www.z  << endl ;
}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

-----------------------------------------------------
int main()
------------------------------------------------------



************************************************************/

