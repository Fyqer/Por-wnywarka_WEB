//***************************************************
// Program z paragrafu   8.15 (str 198)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

/******************************************************/
int main()
{
const char *stacja[] = {
          "Wansee", "Nikolassee", "Grunewald",
          "Westkreuz", "Charlotenburg",
          "Savigny Platz", "Zoologischer Garten" };
const char *www[3] ;
int i ;

     for(i = 0 ; i < 7 ; i++)
     {
          cout << "Stacja: "<< stacja[i] << endl ;
     }
     www[0] = stacja[2] ;
     www[1] = stacja[5] ;
     www[2] = "Taki tekst" ;

     cout << "Oto 3 elementy tablicy : \n"
          << www[0] << ",  "
          << www[1] << ",  "
          << www[2] << endl ;

}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------

int main()

------------------------------------------------------
const char *stacja[] = {    <---------------------- dodane "const"
          "Wansee", "Nikolassee", "Grunewald",
          "Westkreuz", "Charlotenburg",
          "Savigny Platz", "Zoologischer Garten" };
const char *www[3] ;       <---------------------- dodane "const"

Dodany jest przydomek const, za kazdym razem z tego samego powodu:
Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*

------------------------------------------------------


************************************************************/
