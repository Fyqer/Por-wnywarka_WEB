//***************************************************
// Program z paragrafu   8.17.3  (str 221)
//***************************************************

// Uwaga: Program ten musial zostac dramatycznie zmieniony


// Sprawdzony na Linuksie,        kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0




/*----------------------------------------------------
W programie tym wystepuja
trzy funkcje, na ktore pokazujemy wskaznikami ztablicy.
Dla ulatwienia stosujemy tu te same
funkcje wiatraczek, kurs imuzyczka.

----------------------------------------------------*/
/*------------------------------------------------------
Program zostal napisany z wykorzystaniem niektorych
funkcji bibliotecznych charakterystycznych dla kompilatora
          Borland C++ 3.1

W czasach, gdy go pisalem, kompilator ten byl bardzo powszechny,
dlatego uzylem w nim funkcji, ktorych w standardzie nie ma.
Chodzi o funkcje pracujace z klawiatura i glosniczkiem komputera.
Obecnie kompilator BC++ 3.1 jest juz prawie nie uzywany,.
Oczywiscie moglbym poszukac odpowiednikow tych funkcji
w najbardziej popularnych kompilatorach. Tymczasem zalozenie
"Symfonii C++" jest inne. Ma ona opisywac zagadnienia
wspolne dla wszystkich kompilatorow, czyli krotko mowiac
standardowy C++.

Poniewaz newralgiczne funkcje nie sa osia tego zagadnienia
dlatego z nich tu zrezygnowalem.
Zdefiniowalem w programie wlasne wersje tych funkcji.
Ich dzialanie jest nieco inne, ale nie o to tu glownie chodzi.

------------------------------------------------------*/

#include <iostream>
using namespace std ;

#include <cctype>               // dla tolower

//#include <conio.h>               // dla kbhit   <--- usuniete
//#include <dos.h>               // dla sound, nosound, delay   <--- usuniete

#include <cstdlib>          // dla exit

void muzyczka() ;
void wiatraczek() ;
void kurs() ;

int kbhit();

//*****************************************************
void delay(int ile)
{
        for(int i = 0 ; i < ile *100 ; i++) ;
}
/******************************************************/
int main()
{
void (*twf[3])() = { muzyczka, wiatraczek, kurs } ;     //

int co ;

     while(1)
     {
          cout << "Menu :"
               << "\t0 - muzyczka\n\t1 - wiatraczek \n\t"
               << "2 - kurs\n\t3 - koniec programu\n\n"
               << "podaj numer zadanej akcji :" ;
          cin >> co ;                                   //
          switch(co)
          {
               case 0 :
               case 1 :
               case 2 :
                    (*twf[co])() ;                         //
                    break ;
               case 3 :
                    exit(1) ;

               default:
                    break ;
          }
     }
}
/******************************************************/
/******************************************************/
void muzyczka()
{
        cout <<"\a\aZagrala muzyczka..., ale teraz odpowiedz: \n" ;
}
/******************************************************/
void wiatraczek()                              //
{
char t[] = {      '|', '\\',
               '-', '/' };
int i ;

     while(!kbhit() )
     {
          cout << "        " << t[(i++) % 4] << "\r";
          delay(200);
     }
     cout <<"Wiatraczek sie pokrecil..., ale teraz odpowiedz: \n" ;
}
/******************************************************/
void kurs()
{
int i ;
     while(!kbhit() )
     {
          cout << "kurs " << (239 + ((i++) % 4))
                           << "...\r";
          delay(200);
     }
     cout <<"Pokazywalem kurs, ale teraz odpowiedz: \n" ;
}

//*****************************************************
int kbhit()
{
        static int licznik ;

        licznik++ ;
        if(! (licznik % 10000) )
                return 1 ; // oznacza ze wcisnieto klawisz
        else
                return 0 ; // oznacza ze nie wcisnieto

}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------
#include <cstdlib>               // dla exit

------------------------------------------------------

//#include <conio.h>               // dla kbhit  //<---- usuniete
//#include <dos.h>               // dla sound, nosound, delay //<---- usuniete

Usuniete oba naglowki, bo w programie definiujemy swoje wlasne wersje tych
funkcji.

----------------------------------------------------
Usunalem wywolanie funkcji sound, nosound
Zastepuje je
 cout << "\a" ;
czyli wyslanie znaku "alarm" do strumienia cout
co objawia sie sygnalem dzwiekowym glosniczka ("beep")
----------------------------------------------------
void delay(int ile)
{
        for(int i = 0 ; i < ile *100 ; i++) ;
}
Imitacja fukcji delay (opoznienie)


----------------------------------------------------

int main()

------------------------------------------------------


-------------------------------------------------------

Nowa definicja funkcji kbhit to oczywiscie wielkie oszustwo

int kbhit()
{
        static int licznik ;

        licznik++ ;
        if(! (licznik % 10000) )
                return 1 ; // oznacza ze wcisnieto klawisz
        else
                return 0 ; // oznacza ze nie wcisnieto

}
Jak widac, funkcja ta raz na 10000 wywolan odpowiada
zwracajac 1, a w pozostalych wypadkach odpowiada zwracajac 0

Wszystko dlatego, ze funkcja, ktora sprawdza czy ktos wcisnal
jakis klawisz na klawiaturze, albo czy naprzyklad rownoczesnie
jest wcisniety klawisz Ctrl, lub Num Lock nie jest ujeta w standardzie.
To znaczy rozne kompilatory nazywaja ja inaczej, wymagaja innych
argumentow i inaczej odpowiadajac.
Inaczej, to znaczy na przyklad zwracajac strukture, na ktorej
skladanikach jest informacja o sytuacji na klawiaturze.
Aby sie niezaleznic od tych wariantow i dac tu program,
ktory sie da skompilowac za pomoca dowolnego kompilatora C++,
musialem zrezygnowac z tych "wodotryskow".


************************************************************/
