// ***************************************************
// Program z paragrafu   21.15.5 (str 657)
// ***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;
#include <fstream>

// ************************************************************
int main()
{
  ifstream strum ;        // def strumienia do pracy z plikiem
  char nazwa_pliku[50] ;

  // --------otwieranie pliku moze ustawic flage bledu ios_base::failbit

  // w razie gdy plik nie istnieje. Strumien tkwi wowczas  w stanie bledu.
  // Aby ponowic probe otwarcia pliku  flage te trzeba najpierw skasowac


  for(int sukces = 0 ; !sukces ; )
    {
      cout << "Podaj nazwe pliku: " ;
      cin >> nazwa_pliku ;
      cout << endl ;         // kosmetyka ekranu
      // proba otwarcia
      strum.open(nazwa_pliku, ios_base::in);          //

      // czy sie udalo ?
      if(!strum)              // czyli inaczej: strum.fail()
	{
	  cout <<      "Blad otwarcia pliku: "
	       << nazwa_pliku << endl ;
	  // Skoro proba otwarcia nie udala sie to strumien
	  // jest w stanie bledu !!!";
	  // musimy usunac stan bledu strumienia


	  strum.clear(strum.rdstate() & ~ios_base::failbit); // <--- zmiana

	  // strumien juz jest w porzadku. W kolejnym obiegu petli
	  cout << "Ponowiamy probe...\n";
	}
      else
	{                         // udalo sie otworzyc,
	  sukces = 1 ;           // wiec petle mozna zakonczyc
	}
    }                               // koniec petli for

  // -----------------operacje czytania moga wywolac ustawienie flagi bledu
  // ios_base::eofbit w wypadku, gdy dojdziemy do konca pliku
  // i mimo to probujemy czytac nadal. Aby dalej pracowac
  // z tym strumieniem musimy skasowac te flage bledu
  // ( a potem ewentualnie ustawic kursor czytania
  // w poprawne miejsce)

  int numer ;
  char znak ;

  for(int sukces2 = 0 ; !sukces2 ; )
    {
      cout << "Podaj numer bajtu ktory "
	"chcesz poznac: " ;
      cin >> numer ;
      // pozycjonujemy kursor czytania na tym bajcie
      strum.seekg(numer);

      znak = strum.get() ;               //
      if(strum.eof() )
	{
	  cout << "Blad pozycjonowania, "
	    "prawdopodobnie plik\n\t jest krotszy"
	    " niz " << numer << " bajtow\n" ;
	  // strumien tkwi w stanie bledu ios_base::eofbit,
	  // oraz rownoczesnie ios_base::failbit
	  // trzeba go skasowac

	  strum.clear(strum.rdstate() & ~(ios_base::eofbit | ios_base::failbit) ); // <--- zmiana
	  cout << "(Podaj mniejsza liczbe)\n" ;
	  // bedzie ponowny obieg petli

	}
      else {
	sukces2 = 1 ;
	cout << "Ten bajt to ASCII: '"  << znak
	     << "' hexadecymalnie " << hex
	     << (int)znak << endl ;
      }
    }
  // ------------------proba formatowanego wczytania liczby w sytuacji, gdy
  // wlasnie oczekuje na wczytanie cos, co liczba nie jest,
  // - wprowadzi sturmien w stan bledu ios_base::failbit

  int liczba ;
  // instrukcja wczytania liczby - rozpocznie czytac zaraz po

  // wczytanym poprzednio bajcie
  strum >> liczba ;          //
  // czy sie udalo ?
  if(strum.fail() )
    {                                     // nie !
      cout <<      "Blad failbit, bo najblizsze "
	"bajty\n\t nie moga "
	"byc wczytane jako liczba\n" ;

      // Aby to cos wowczas wczytac jako string
      // nalezy najpierw skasowac ustawiona flage bledu
      strum.clear(strum.rdstate() & ~ios_base::failbit);
      // strumien nadaje sie do pracy, a to cos, co go
      // zatkalo, nadal czeka na wczytania
      char slowo[80] ;
      strum >> slowo ;
      cout << "Jest to slowo: "<< slowo << endl;

    }else{
    // tak !
    cout << "Pomyslnie wczytana liczba: "
	 << liczba << endl;
  }
  // dalsza praca z plikem ....
}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <fstream>
------------------------------------------------------
int main()
------------------------------------------------------
Poniewaz blad otwarcia (nieistniejacego) pliku
powoduje ustawienie flagi failbit (a nie badbit)
zatem jest tam nowa linijka:

  if(!strum)              // czyli inaczej: strum.fail()
  {
      cout <<      "Blad otwarcia pliku: "
           << nazwa_pliku << endl ;
	   // Skoro proba otwarcia nie udala sie to strumien
	   // jest w stanie bledu !!!";
	   // musimy usunac stan bledu strumienia


      strum.clear(strum.rdstate() & ~ios_base::failbit); // <--- zmiana

      // strumien juz jest w porzadku. W kolejnym obiegu petli
      cout << "Ponowiamy probe...\n";
   }

--------------------------------------------------------
Proba pozycjonowania kursora czytania poza koncem
pliku ustawi flage eofbit, ale TAKZE failbit
dlatego trzeba skasowac obie flagi

Oto stosowny fragment, zmiana jest zaznaczona w komentarzu.

if(strum.eof() )
{
   cout << "Blad pozycjonowania, "
        "prawdopodobnie plik\n\t jest krotszy"
        " niz " << numer << " bajtow\n" ;

        // strumien tkwi w stanie bledu ios_base::eofbit,
        // oraz rownoczesnie ios_base::failbit
        // trzeba go skasowac

  strum.clear(strum.rdstate() & ~(ios_base::eofbit | ios_base::failbit) ); <--- ZMIANA
  cout << "(Podaj mniejsza liczbe)\n" ;
  // bedzie ponowny obieg petli

}


-------------------------------------------------
Kwalifikator ios::
zastapiony zostal przez ios_base::
w calym tym programie.


************************************************************/


