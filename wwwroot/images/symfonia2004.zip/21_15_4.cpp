//***************************************************
// Program z paragrafu   21.15.4 (str 656)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;
#include <fstream>

class slowo_na_e {
public:
       char wyraz [80] ;
} ;
////////////////////////////////////////////////////////
istream & operator >>(istream & str, slowo_na_e & w)
{
     str >> w.wyraz ;
     if(w.wyraz[0] != 'e'){
          str.clear(str.rdstate() | ios::failbit  ) ;//
     }
     return str ;
}
/******************************************************/
int main()
{
slowo_na_e pierwsze, drugie, trzecie ;

     while(1){
          cout << "Podaj trzy slowa na litere 'e' : " ;
          cin >> pierwsze >> drugie >> trzecie ;         //

          if(!cin) {
               cout << "\nZle  ! Od poczatku : " ;
               cin.clear(cin.rdstate() & ~ios::failbit);//
          }
          else break ;     // jesli poprawnie
      }
}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <fstream>
------------------------------------------------------
int main()
------------------------------------------------------

************************************************************/


