//***************************************************
// Program z paragrafu   19.7.4 (str 518)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

enum kolor { czarny, czerwony, niebieski, bialy } ;
/////////////////////////////////////////////////////////
class pojazd                                           //
{
protected:
     int ilosc_kol ;
public:
     pojazd(int ile) : ilosc_kol(ile) {}
     pojazd(const pojazd &) ;
     pojazd & operator=(const pojazd & wz) ;
     // ...
};
/////////////////////////////////////////////////////////
class automobil : public pojazd                          //

{
     int stan_licznika ;
     kolor  kolor_karoserii;
public :
     automobil(int kola, kolor k , int licznik):pojazd(kola)

     {
          stan_licznika = licznik ;
          kolor_karoserii = k ;
     }
     automobil(const automobil &);
     automobil & operator=(const automobil &ww) ;
     friend ostream &
          operator<<(ostream & ekran,
                                   const automobil & obj) ;
} ;
/*******************************************************/
/* definicje konstruktorow kopiujacych dla obu klas ***/
/*******************************************************/
pojazd::pojazd(const pojazd & wzor)
{
     ilosc_kol = wzor.ilosc_kol ;
}
/*******************************************************/
automobil::automobil(const automobil & wzorzec)
                                   : pojazd(wzorzec)
{                                                    //

     stan_licznika = 0 ;
     kolor_karoserii = wzorzec.kolor_karoserii ;
}
/*******************************************************/
/*** definicje operatorow przypisania dla obu klas  ****/
/*******************************************************/
pojazd & pojazd::operator=(const pojazd & wz)
{
     ilosc_kol = wz.ilosc_kol ;
     return *this ;                                   //
}
/*******************************************************/
automobil & automobil::operator=(const automobil &wzor)
{                                                    //

     // ---------------trzy sposoby zrobienia tego samego
     // ----- wywolanie jawne -----------

     (*this).pojazd::operator=(wzor) ;

     // ----- niejawnie: operator = z kasy podstawowej wywolujemy tak
     pojazd *wskpojazd = this ;
     (*wskpojazd) =  wzor ;
     // ----albo tak (referencjami)-----------

     pojazd & refpojazd = *this ;
     refpojazd = wzor ;

     // dalej tylko dokanczamy robote
     kolor_karoserii = wzor.kolor_karoserii ;           //

     stan_licznika = wzor.stan_licznika + 2;
     return *this ;
}
/*******************************************************/
/* Aby sie oswoic z przeladowywaniem operatora <<    **/
/*******************************************************/
ostream & operator<<(ostream & ekran, const automobil & obj)

{
     ekran << " Liczba kol "     << obj.ilosc_kol
           << ", Licznika " << obj.stan_licznika
           << ", kolor nr " << obj.kolor_karoserii <<endl;
     return ekran ;
}
/*******************************************************/
int main()
{
automobil moj(4, bialy, 30000) ;
automobil twoj = moj ;                                 //

     cout << "Lista istniejacych automobili \n"
          << "moj  " << moj                               //
          << "twoj " << twoj ;

     automobil dziwak(3, bialy, 5000) ;
     cout << "Jeszcze jeden o nazwie dziwak :\n"
          << dziwak  ;

     dziwak = moj ;                                    //

     cout << "dziwak po przypisaniu :\n"<< dziwak ;

     const automobil muzealny(4, czerwony, 25000) ;     //
     dziwak = muzealny ;

     cout << "Muzealny    : " << muzealny ;
     cout << "Dziwak po... " << dziwak ;
}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------

-------------------------------------------------------
int main()
------------------------------------------------------



************************************************************/


