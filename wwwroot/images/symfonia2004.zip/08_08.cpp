//***************************************************
// Program z paragrafu  8.8 (str 174)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 

#include <iostream>
using namespace std ;

void     hydraulik(int *wsk_do_kranu) ;                    //
//****************************************************
int main()
{
int kran = -1 ;                                        //

     cout << "Stan techniczny kranu = "<< kran << endl ;
     hydraulik( &kran ) ;                              //
     cout <<
       "Po wezwaniu hydraulika stan techniczny kranu = "
          << kran << endl ;                               //

}
/******************************************************/
void     hydraulik(int *wsk_do_kranu)                     //
{
     *wsk_do_kranu = 100 ;               // akcja naprawiania
}                                                        //


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------

int main()

************************************************************/
