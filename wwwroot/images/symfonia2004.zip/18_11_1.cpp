//***************************************************
// Program z paragrafu   18.11.1 (str 455)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;


#include <cstring>             // strcpy

/////////////////////////////////////////////////////////
class wizytowka {
     char *nazw ;
     char *imie ;
public :

     wizytowka(const char *n, const char *im) ;    // konstruktor
     wizytowka(const wizytowka &wzor) ;//  konstr. kopiujacy
     ~wizytowka();                          // destruktor
     void pisz(const char *) ;
                                   // - operator przypisania
     wizytowka &  operator=(const wizytowka &wzor) ;
} ;
////////////////////////////////////////////////////////
wizytowka::wizytowka(const char*n, const char *im)
{
     nazw = new char[strlen(n) + 1] ;                    //
     imie = new char[strlen(im) + 1] ;
     if(n)  strcpy(nazw, n);                                   //
     if(im) strcpy(imie, im);
     cout << "Pracuje konstruktor zwykly" << endl ;
}
/******************************************************/
wizytowka::wizytowka(const wizytowka &wzor)         //

{
     nazw = new char[strlen(wzor.nazw) + 1] ;
     imie = new char[strlen(wzor.imie) + 1] ;
     strcpy(nazw, wzor.nazw);
     strcpy(imie, wzor.imie);
     cout << "Pracuje konstruktor kopiujacy " << endl ;
}
/******************************************************/
wizytowka::~wizytowka()                               //
{
     delete [] nazw ;
     delete [] imie ;
}
/******************************************************/
void wizytowka::pisz(const char *txt)
{
     cout << "   " << txt
          << ":  Mamy goscia, jest to "
          << imie << " " << nazw << endl ;
}
/*******************************************************/
wizytowka & wizytowka::operator=(const wizytowka &wzor)
{                                                     //

     // -- czesc "destruktorowa" ------

     delete [] nazw ;
     delete [] imie ;
     // -- czesc "konstruktorowa (konst. kopiujacy)"-

     nazw = new char[strlen(wzor.nazw) + 1] ;
     imie = new char[strlen(wzor.imie) + 1] ;
     strcpy(imie, wzor.imie);
     strcpy(nazw, wzor.nazw);
     cout << "Pracuje operator= (przypisania)\n" ;
     return *this ;
}
/******************************************************/
int main()
{
     cout << "Definicje 'veneziano', i 'salzburger' \n" ;

wizytowka veneziano("Vivaldi", "Antonio"),           //

          salzburger("Mozart", "Wolfgang A.");

     cout << "Definicja 'nowy' : \n" ;

wizytowka nowy = veneziano ;         // konstruktor kopiujacy
     cout << "Oto tresc w obiektach\n" ;

     veneziano.pisz("ven1");                              //
     salzburger.pisz("sal1");
     nowy.pisz("now1");

     cout << "Zabawy z przypisywaniem ---\n" ;

     nowy = salzburger ;                              //

     nowy.pisz("now2");
     nowy = veneziano ;
     nowy.pisz("now3");

     nowy = salzburger = veneziano ;                  //

     nowy.pisz("now4");
     salzburger.pisz("sal4");
     veneziano.pisz("ven4");
}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <cstring>
------------------------------------------------------


-----------------------------------------------------
W konstruktorze
     wizytowka::wizytowka(const char*n, const char *im)  <-- 2 x const
     void wizytowka::pisz(const char *txt) <--- const
( zmiany sa deklaracjach a takze potem w definicjach tych funkcji)

Dodany jest przydomek const, za kazdym razem z tego samego powodu:
Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*


-----------------------------------------------------
Dodatkowo w konstruktorze  wizytowka::wizytowka(const char*n, const char *im)

     if(n)  strcpy(nazw, n);     // <----- dodane sprawdzenie if                              //
     if(im) strcpy(imie, im);    // <----- dodane sprawdzenie if


bo gdybyw wskaznik n lub im mial wartosc zero, to funkcja
strcpy wywolaby  blad pamieci
-----------------------------------------------------
int main()
------------------------------------------------------
wizytowka::~wizytowka()                               //
{
     delete [] nazw ;   <-- dodane [] 
     delete [] imie ;	<-- dodane [] 
}

------------------------------------------------------
wizytowka & wizytowka::operator=(const wizytowka &wzor)
{                                                     //

     // -- czesc "destruktorowa" ------

     delete [] nazw ;	<-- dodane [] 
     delete [] imie ;	<-- dodane [] 



************************************************************/

