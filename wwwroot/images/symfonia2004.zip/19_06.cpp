//***************************************************
// Program z paragrafu   19.6 (str 511)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;


////////////////////////////////////////////////////////
class silnik
{
protected :
     int     typ ;
public :
     silnik(int n) : typ(n)
     {     cout << "\tKonstruktor silnika "
                    "(skladnik samochodu)\n"; }

     ~silnik()
     {     cout << "\tDestruktor silnika  "
                    "(skladnik samochodu)\n" ; }
} ;
////////////////////////////////////////////////////////
class klimatyzacja
{
     float temperat ;
public:
     int nic ;
     klimatyzacja(float t) : temperat(t)
     {
       cout << "\t\tKonstruktor klimatyzacji  "
                    "(skladnik mercedesa)\n" ;
     }

     ~klimatyzacja()
     {
       cout << "\t\tDestruktor klimatyzacji  "
                    "(skladnik mercedesa)\n" ;
     }
};
////////////////////////////////////////////////////////
class sr_transportu
{
protected:
     float poz_x ,          // biezace wsp�lrzedne
           poz_y ;          // np. geograficzne
public:
     sr_transportu()
     { cout << " Konstruktor sr_transportu\n" ; }
     ~sr_transportu()
     { cout << " Destruktor sr_transportu\n" ; }
};
/////////////////////////////////////////////////////////
class samochod : public sr_transportu
{
protected :
     int aa ;
     silnik jego_silnik ;
public :
                                                       //
     samochod(int typ_silnika)
               : sr_transportu(),  jego_silnik(typ_silnika)
     {
          cout << "\tKonstruktor samochodu \n" ;
     }

     ~samochod()
     {
          cout << "\tDestruktor samochodu \n" ;
     }
} ;
/////////////////////////////////////////////////////////
class mercedes : public samochod {
protected :
     float xxx ;
     klimatyzacja casablanca ;
public :
     mercedes(float x, int typ_motoru, float klim) :
                    samochod(typ_motoru),   //
                    xxx(x),
                    casablanca(klim)
     {     cout << "\t\tKonstruktor mercedesa\n" ; }

     ~mercedes()
     {     cout << "\t\tDestruktor mercedesa\n" ; }
} ;
/*******************************************************/
int main()
{
     {
          cout << "Kreacja obiektu klasy samochod \n" ;

          samochod czarny(500) ;
          cout << "\nobiekt czarny samochod istnieje \n"
          "teraz bedzie likwidowany !\n\n" ;
     }
     cout << "obiekt samochod zlikwidowany\n\n" ;
     {
          cout << "Kreacja obiektu klasy mercedes \n" ;
          mercedes popielaty(6.5, 1200, 22.5) ;
          cout << "obiekt Mercedes istnieje \n"
          "teraz bedzie likwidowany !\n" ;
     }
     cout << "obiekt Mercedes zlikwidowany\n" ;
}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------
class klimatyzacja
{
     float temperat ;  <-- zmienilem z typu int na float
------------------------------------------------------
     samochod(int typ_silnika)
               : sr_transportu(),  jego_silnik(typ_silnika)
Zmienilem kolejnosc na liscie inicjalizacyjnej.
W mysl nowego standardu, kolejnosc na liscie inicjalizacyjnej
ma znaczenie. Najpierw powinny na tej liscie klasy podstawowe,
potem dopiero inicjalizacja wlasnych skladnikow

------------------------------------------------------

     mercedes(float x, int typ_motoru, float klim) :
                    samochod(typ_motoru),   //
                    xxx(x),
                    casablanca(klim)

Zmiana kolejnosci na liscie inicjalizacyjnej - z tego
samego powodu co powyzej. Inicjalizacja skladnika xxx
powinna sie odbyc PO inijalizacji "samochodu" (kl podstawowa).
------------------------------------------------------
     mercedes(float x, int typ_motoru, float klim) :

W tym samy konstruktorze, zmienilem typ trzeciego
argumentu z int na float.
Nie ma to specjalnego znaczenia dla omawianych tu spraw.

-------------------------------------------------------
int main()
------------------------------------------------------



************************************************************/


