//***************************************************
// Program z paragrafu   10.14 (str 291)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;

#include <cstring>               // bo uzyjemy: strcpy()

/////////////////////////////////////////////////////////
class gadula {
     int      licz ;
     char tekst[40] ;
public :

     // konstruktor
     gadula(int k, const char *opis) ;

     // destruktor - deklaracja
     ~gadula(void) ;                                   //

     // inne funkcje skladowe
     int zwracaj() { return licz ; }
     void schowaj(int x) { licz = x ; }
     void coto()
     { cout << tekst << " ma wartosc "<< licz << endl; }
} ;
////////////////////////////////////////////////////////
gadula::gadula(int k, const char *opis)          // konstruktor
{
      if(opis) strcpy(tekst, opis);
     else      tekst[0] = 0 ; // pusty string
     licz = k ;
     cout << "Konstruuje obiekt " << tekst << endl ;
}
/******************************************************/
gadula::~gadula()                         // destruktor
{
     cout << "Pracuje destruktor (sprzata) "
          << tekst << endl ;
}
/******************************************************/
gadula a(1, "obiekt a (GLOBALNY)");                    //
gadula b(2, "obiekt b (GLOBALNY)");
/******************************************************/
int main()
{
     a.coto() ;
     b.coto() ;                                         //
     {                    // <-- !
          cout << "Poczatek lokalnego zakresu --------\n";
          gadula c(30, "obiekt c (lokalny)");         //
          gadula a(40, "obiekt a (lokalny)"); // zaslania !


          cout << "\nCo teraz mamy :\n" ;
          a.coto() ;                                   //
          b.coto() ;
          c.coto() ;

          cout << "Do zaslonietego obiektu globaln mozna "
                    "sie jednak dostac\n" ;
          ::a.coto() ;                                //
          cout << "Konczy sie lokalny zakres ---------\n";
     }                                                  //
     cout << "Juz jestem poza blokiem \n" ;
     a.coto() ;                                        //
     b.coto() ;
     cout << "Sam uruchamiam destruktor obiektu a\n";
     a.gadula::~gadula() ;                          //
     cout << "Koniec programu !!!!!!!!\n";         //

}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <cstring>

------------------------------------------------------

gadula::gadula(int k, const char *opis)          // konstruktor

W tej deklaracji a takze potem w definicji tej funkcji dodane zostaly
przydomki "const", za kazdym razem z tego samego powodu:
Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*

------------------------------------------------------
int main()

-------------------------------------------------------
W definicji konstruktora gadula  dodane zostalo sprawdzenie
czy wskaznik do stringu nie pokazuje czasem na adres 0 (NULL).
Gdyby tak bylo, to funkcja strcpy spowodowalaby blad pamieci.
Zatem najpierw to sprawdzamy, a jesli ta, to do tablicy tekst
wpisujemy 0 do zerowego elementu, co odpowiada pustemu stringowi

gadula::gadula(int k, const char *opis)          // konstruktor
{
      if(opis) strcpy(tekst, opis);
     else      tekst[0] = 0 ; // pusty string
     licz = k ;
     cout << "Konstruuje obiekt " << tekst << endl ;
}

------------------------------------------------------
Uwaga: To, kiedy dokladnie likwidowane sa obiekty - jest zalezne
od konkretnego kompilatora. To jest jego prywatna sprawa,
wiec kompilujac ten przyklad roznymi kompilatorami
mozesz otrzymywac program wypisujacy teksty destruktora
w nieco innym miejscu (czyli czasie).


************************************************************/
