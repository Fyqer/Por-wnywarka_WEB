// ***************************************************
// Program z paragrafu   18.9 (str 443)
// ***************************************************

// Sprawdzony na Linuksie,    kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


// UWAGA: Dramatyczne zmiany. Wyrzucone wszystkie funkcjie niestandardowe
// (dawniej byly tu funkcje z Borlanda C++ 3.1).
// Szczegoly ponizej.

// Po raz pierwszy zastosowalem te sposoby w przykladzie 14_1_1.cpp


#include <iostream>
using namespace std ;


#include <cstring>             // strcpy
#include <ctime>               // time

void zwloka(int sekund); // sama deklaracja

// ***********************************************************
// Aby mozliwe bylo pisanie na ekranie w miejscach o okreslonych
// wspolrzednych stosuje pewien chwyt. Otoz zamiast pisac wprost
// na ekranie, - "piszemy" w tablicy znakowej o rozmiarach [25][80].
// Takie zwykle sa monitory alfanumeryczne: maja one 80 znakow w linii,
// a na ekranie jest takich linii 25
// Funkcja skladowa o nazwie wyczysc, kasuje poprzednia tresc
// "ekranu" i zapelnia wstepnie kropkami. (Pierwotnie zapelnialem
// spacjami, ale teraz kropki podobaja mi sie bardziej).
// Dodatkowo na koncu kazdej linii wpisywany jest znak nowej linii
// a na samy koncu jest znak null. Dzieki temu, te dwuwymiarowa
// tablice mozemy wypisac na ekranie jedna instrukcja - jako jeden
// string, ktory w okreslonych miejscach ma znaki przejscia do nowej
// linii.

// Gdy taka tablica znakow jest juz zapelniona sensowna trescia, wypisujemy
// ja na ekranie funkcja skladowa o nazwie wyswietl.

// Oczywiscie wszystko to ma sens tylko wtedy gdy czcionki piszace
// po ekranie sa proporcjonale - czyli gdy szerokosc wszystkich znakow
// jest taka sama. (znak 'W' jest tak samo szeroki jak znak '.').
// Tak wlasnie jest w wypadku ekranu alfanumerycznego.
// Jesli u Ciebie jest inaczej, zmien czcionke na proporcjonalna,
// (porporcjonalna jest na przyklad czcionka "Courier").
// To jest glowny powod, dla ktorego zastosowalem kropki a nie spacje -
// dzieki temu od razu zauwazysz, gdybys mial czcionke nieproporcjonalna.


// Ponizsza klasa nic nie wie o zadnych "okienkach". Potrafi tylko
// wypisac tekst w miejscu o okreslonych wspolrzednych (wzglednych)
// i ewentualnie zamalowac dany obszar kolorem (tu oszukiwanym za
// pomoca dowolnego znaku ASCII)
// (okienkami natomiast zajmuje sie inna klasa "zarzadca_okien").
// ***********************************************************
class ekran_alfanumeryczny
{
  char tresc[25][80] ;

  // zapamietane granice okienka na ktorym przeprowadza sie nastepne
  // operacje
  int xx1, xx2;
  int yy1, yy2 ;
  char znak_tla ;

public:
  ekran_alfanumeryczny() : xx1(0), xx2(79), yy1(0), yy2(24), znak_tla('.')
  {
    wyczysc() ;
  }
  //--------------------
  void wyczysc()
  {
    // wypelnienie zadanego fragmentu "ekranu" biezacym znakiem
    for(int y = yy1 ; y <= yy2 ; y++)
      for(int x = xx1 ; x <= xx2 ; x++)
	tresc[y][x] = znak_tla ;

    // wstawienie znakow przejscia do nowej linii ekranowej
    // na koncu kazdej linii
    for(int i = 0 ; i < 25 ; i++)
      {
	tresc[i][79] = '\n';
      }
    // ostatecznie wstawienie znaku null konczacego obrazek
    tresc[24][79] = 0;  // <--- null

    wyswietl();
  }
  //--------------------
  void wyswietl()
  {
    cout << &tresc[0][0] << flush ;
  }
  //-------------------
  // funkcja skladowa wpisujaca w miejscu o wspolrzednych x,y
  // zadany tekst
  // Uwaga: wspolrzedne sa wzgledem obszaru zdeklarowanego
  // wczesniej jako "window", czyli nie wzgledem 0,0 ale xx1, yy1
  void napisz(int x, int y, const char* tekst)
  {

    for(unsigned int i = 0 ; i < strlen(tekst) ; i++)
      tresc[yy1+ y][xx1+ x+i] =  tekst[i];

    // wyswietlenie tego odbedzie sie tylko na wyrazne zadanie
    // bo czasem chcemy duzo wypisac, a potem tylko raz odswiezyc
    // (przykladem jest chociazby procedura rysowania ramki okna).
  }
  //----------------------
  void ustaw_znak_tla(char z) { znak_tla = z ; }
  //-----------------------

  // zapamnietanie na jakim obszarze monitora teraz pracujemy
  void obszar(int x1, int y1, int x2, int y2)
  {
    xx1 = x1 ; xx2 = x2 ;
    yy1 = y1 ; yy2 = y2 ;
  }
};
//////////////////////////////////////////////////////////////
ekran_alfanumeryczny monitor ;  // definicja globalnego obiektu

// ***********************************************************
class okno ;          // deklaracja zapowiadajaca

/////////////////////////////////////////////////////////
// definicja klasy odpowiadajacej za ustawianie okien na ekranie
// wzgledem siebie, wyjmowanie niektorych na wierzch itd.
// Tu jest caly "program naukowy" tego przykladu.
/////////////////////////////////////////////////////////
class zarzadca_okien {                                        //
  okno * tab_okn[20] ;                // tablica wskaznikow
  int pierwsze_wolne ;
public:
  // konstruktor
  zarzadca_okien()
  {
    pierwsze_wolne = 0 ;
  }
  void odswiez();     // narysowanie obecnego stanu ekranu
  void mazanie();     // mazanie tresci calego ekranu
  // ------------ przeladowane operatory
  void operator +=(okno & ref_ok) ;   // dodawanie okienka
  zarzadca_okien & operator +(okno & ref_ok);// dodawanie okienek
  void operator -=(okno & ref_ok) ;          // usuwanie okienka
  void operator != (okno & ref_ok) ;     // wyjmowanie na
  // sam wierzch
};
///////////////////////////////////////////////////////
class okno {                                             //
  int x, y, wys, sz ;     // geometria okna
  char kolor ;               // kolor okienka
  char tytul[20] ;          // opis okienka
public:
  okno(int xx, int yy, int ss, int ww,
       char kk, const char * tt)
    : x(xx), y(yy), wys(ww), sz(ss), kolor(kk)
  {
    if(tt) strcpy(tytul, tt);
  }
  // dodanie okienka w operacji pulpit = pulpit + okienko
  zarzadca_okien operator +(okno & m2) ;
  void narysuj_sie() ;
};
////////////////////////////////////////////////////////
// definicje funkcji skladowych klasy okno
/******************************************************/
void okno::narysuj_sie()
{
  monitor.obszar(x,y, x+sz-1, y+wys-1);     // obszar pracy
  monitor.ustaw_znak_tla(kolor);// ustal kolor tla
  monitor.wyczysc() ;                    // zamaluj kolorem tla

  // narysowanie ramki - dwie linie poziome -------------
  char linijka[80] ;
  int i = 0 ;

  for(; i < sz+1; i++)    linijka[i] = '-' ;
  linijka[i] = 0 ; // znak null

  monitor.napisz(0,  0,   linijka) ;
  monitor.napisz(0,  wys,   linijka) ;

  // c. d. rysowania ramki - dwie linie pionowe------------
  for(i = 0; i < wys+1; i++)
    {
      monitor.napisz(0,  i,   "|") ;
      monitor.napisz(sz,  i,  "|") ;
    }

  // napisanie tytulu okna na srodku pierwszej linijki
  monitor.napisz((sz-strlen(tytul)) / 2, 0 ,   tytul) ;
  monitor.wyswietl();
}
/******************************************************/
zarzadca_okien okno::operator +(okno & m2)                 //
{
  // dodanie okienek do chwilowego pulpitu roboczego
  zarzadca_okien roboczy ;
  roboczy += *this ;        // dodajemy pierwsze (pulpit += okno)
  roboczy += m2 ;        // dodajemy drugie
  return roboczy ;        // zwracamy pulpit (przez wartosc)
}
/*****************************************************/
// definicje funkcji skladowych klasy zarzadca_okien
/*****************************************************/

void zarzadca_okien::operator +=(okno & ref_ok)                    //  dodawanie okna
{

  tab_okn[pierwsze_wolne++] = &ref_ok ;
  odswiez();
}
/*****************************************************/
void zarzadca_okien::operator -=(okno & ref_okna)
{                                             // usuwanie okna
  // odszukanie w tablicy wskaznika do tego okna
  int i= 0 ;
  for( ; i < pierwsze_wolne ; i++)
    {
      if(tab_okn[i] == &ref_okna) break ;
    }

  // sprawdzamy jak zakonczylo sie poszukiwanie
  if(i == pierwsze_wolne)
    {
      // tzn. takiego okna nie ma obecnie na pulpicie
      // wiec po prostu nic nie robimy
    }
  else
    {     // okno odszukane, to je usuwamy ztablicy
      for(int k = i ; k < pierwsze_wolne ; k++)
	{      // przesuwanie pozostalych
	  tab_okn[k] = tab_okn[k+1] ;
	}
      pierwsze_wolne -- ;
    }
  mazanie();     // najpierw musimy zmazac caly pulpit
  odswiez();
}
/*****************************************************/
/* wydobycie na sam wierzch zadanego okienka */
void zarzadca_okien::operator != (okno & ref_ok)               //
{
  // polega na postawieniu go na samym koncu tablicy
  // w tym celu najprosciej usunac je zlisty i natychmiast dodac

  *this -= ref_ok ;          // czyli pulpit -= okno
  *this += ref_ok ;          // czyli pulpit += okno
  odswiez();
}
/*****************************************************/
void zarzadca_okien::odswiez()                              //
{
  for(int i = 0 ; i < pierwsze_wolne ; i++)
    {
      tab_okn[i]-> narysuj_sie();
    }
}
/*****************************************************/
void zarzadca_okien::mazanie()
{
  // caly pulpit wypelniam spacjami (lub kropkami)

  monitor.ustaw_znak_tla('.');  // maja byc kropki
  monitor.obszar(1,1, 80, 25);          // na takim obszarze
  monitor.wyczysc() ;                    // wykonac!
}
/******************************************************/
zarzadca_okien & zarzadca_okien::operator +(okno & ref_ok)          //
{                                    // dodanie okna do pulpitu
  *this += ref_ok ;               // czyli pulpit += okno
  return *this ;                    // czyli return pulpit
}
/******************************************************/
int main()
{
  monitor.ustaw_znak_tla('.');
  monitor.wyczysc() ;

  zarzadca_okien pulpit ;               // definicja obiektu pulpit

  // definicja kilku okienek
  okno gra(15, 5,  21, 3, '$', "Gra w Chinczyka");
  okno kalkulator(2,3,  14,3, '@', "Kalkulator");
  okno edytor(7,4, 18,3, ':', "Edytor");

  // umieszczenie okien na pulpicie

  pulpit = gra + kalkulator + edytor ;               //
  zwloka(1) ;

  // wymyslamy jeszcze jedno okno
  okno zegar(4,6,18,3, '%', "Zegar");

  pulpit += zegar ;     // dodanie go do obecnego pulpitu

  zwloka(1) ;
  pulpit != kalkulator ; // wyjecie kalkulatora na sam wierzch

  zwloka(1) ;
  pulpit != gra ;          // teraz wyjecie gry
  zwloka(1) ;
  pulpit -= kalkulator ;         // usuniecie jednego zokien

  zwloka(1) ;


}
// ********************************************************
// Dodatkowo zdefiniowalem funkce zwloka, ktora powoduje w programie
// zwloke czasowa o dlugosci zadanej liczby sekund
// ********************************************************
void zwloka(int sekund)
{
  static time_t poprzedni_czas = time(NULL) ;
  while(time(NULL) - poprzedni_czas < sekund)  ;   // cialo puste

  poprzedni_czas = time(NULL) ;
}


/************************************************************
Jak widac...
------------------------------------------------------
Caly program przeszedl gruntowna przerobke

W dodatku - aby uniknac nieporozumien  zmienilem nazwe klasy:
        kl_ekran
nazywa sie teraz
        zarzadca_okien

W funkcji main obiekt tej klasy nie nazywa sie "ekran" ale "pulpit".

ALE  uwaga, nie daj sie zwiesc: zmiany dotycza tylko pracy z monitorem -
i wynikaja z tego ze w standardzie nie ma funkcji odpowiedzialnych
za wypisywanie tekstu w dowolnie wybranym miejscu. Istota programu
jest jednak nie ekran ale zarzadca okien i jego przeladowane operatory.
Tu zmian nie ma, a wyjasnienia z ksiazki sa jak najbardziej w mocy.


 -----------------------------

 Dodalem definicje funkcji 
  void zwloka(int sekund);
ktora zastapila niestandardowa funkcje sleep


************************************************************/

