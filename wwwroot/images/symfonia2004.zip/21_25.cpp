//***************************************************
// Program z paragrafu   21.25 (str 690)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;


// PRZESTARZALY
#include <strstream>   // <--- bo uzywamy istrstream

// NOWY SPOSOB
#include <sstream>   // <-- bo  uzywamy istringstream

/*******************************************************/
int main()
{

cout << "#### stary sposob ####" << endl;

//char pasek[80] ;

//strstream p(pasek, sizeof(pasek)); //, ios_base::in | ios_base::out);
strstream p;

     p << "032 10 45.67" << endl ;

    // cout << "Dla sprawdzienia p.str = " << p.str() ;

    int i= -3, j = -3 ;
    float x = -22.22 ;

     p >> i ;
     p >> j >> x ;

     cout << "i = "<< i << endl ;
     cout << "j= "<< j << endl ;
     cout << "x = "<< (x) << endl ;

     cout << "suma = "<< (i + j + x) << endl ;

     // mozna takze pozycjonowac kursory pisania i czytania
     p.seekg(2, ios_base::beg) ;

     // i stosowac funkcje skladowe klas podstawowych
char t[20] ;
     p.getline(t, sizeof(t) ) ;
     t[6] = 0 ; // czyli znak null ;
     cout << "Znaki wyjete ze srodka = " << t << endl ;



cout << "#### Nowy sposob ####" << endl;

  i= -3;
  j = -3 ;
  x = -22.22 ;  // dla pewnosci zacieram poprzedni rezultat


stringstream pp;

     pp << "032 10 45.67" << endl ;


     pp >> i ;
     pp >> j >> x ;

     cout << "i = "<< i << endl ;
     cout << "j= "<< j << endl ;
     cout << "x = "<< (x) << endl ;

     cout << "suma = "<< (i + j + x) << endl ;

     if(!pp) cout << "1Blasfd pp " << endl;
     // mozna takze pozycjonowac kursory pisania i czytania
     pp.seekg(2, ios_base::beg) ;
     if(!pp) cout << "2Blasfd pp " << endl;
     // i stosowac funkcje skladowe klas podstawowych
     pp.getline(t, sizeof(t) ) ;
     t[6] = 0 ; // czyli znak null ;

     if(!pp) cout << "2Blasfd pp " << endl;
     cout << "Znaki wyjete ze srodka = " << t << endl ;

}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;


// PRZESTARZALY
#include <strstream>   // <--- bo uzywamy istrstream

// NOWY SPOSOB
#include <sstream>   // <-- bo  uzywamy istringstream

------------------------------------------------------
int main()
------------------------------------------------------
Korzystamy tutaj z przestarzalej klasy
  strstream
podczas gdy powinnismmy tu juz uzyc
  stringstream


Druga czesc programu pokazuje to samo z uzyciem
nowoczesniejszej klasy.

------------------------------------------------------
//char pasek[80] ;
//strstream p(pasek, sizeof(pasek)), ios_base::in | ios_base::out);

Tablica pasek jest w zasadzie do niczego nie potrzebna
Stumien obsluzy sie za pomoca swojej wlasnej tablicy
("Mechanizm automatycznej rezerwacji miejsca").

Dodatkowo tryb otwarcia nie jest potrzebny, bo takie
wlasnie jest domniemanie, zatem nie ma sensu tego
tu powtarzac.
Zostaje wiec prosta instrucja:

strstream p;

--------------------------------------------------------
Z ponizszego string usunalem znak 'x' gdyz - jak widze -
operator >> (tej klasy) nie radzi sobie z interpretacja
liczby w kodzie szesnastkowym (0x32)


     p << "032 10 45.67" << endl ;


------------------------------------------------------


Oprocz starego sposobu, do ktorego nowy standard juz
zniecheca - (choc ciagle akceptuje) pokazuje tu
lepszy sposob - z uzyciem klasy o nazwie ostringstream


Ten nowy sposob realizowany jest za pomoca strumienia
innej, standardowej klasy

 stringstream pp;

 Jak widac dzialanie jest takie same.
-------------------------------------------------------
W obu wypadkach uzyta jest funkcja getline.
Jak pamietamy czyta ona znaki az do ogranicznika.
Jesli go nie napotka, to nastepuje blad.
Aby tego uniknac, string zakonczylismy konca linii (endl).


     p << "032 10 45.67" << endl ;

Dla innych funkcji nie mialo to znaczenia, ale
jesli uzywamy getline - to trzeba o tym pamietac.

------------------------------------------------------
Wszystkie wystapienia kwalifikatora ios:: zostaly
zamienione na ios_base::


************************************************************/


