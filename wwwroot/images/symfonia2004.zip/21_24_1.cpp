//***************************************************
// Program z paragrafu   21.24.1 (str 688)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;


// PRZESTARZALY
#include <strstream>   // <--- bo uzywamy istrstream

// NOWY SPOSOB
#include <sstream>   // <-- bo  uzywamy istringstream

/*******************************************************/
int main(int argc, char* argv[])                          //
{
float x, z ;
char nazwisko[40] ;


cout << "######## Stary sposob ###############" << endl;

istrstream s1(argv[1]) ;                               //
           s1 >> x ;                                  //

istrstream s2(argv[2]) ;                                 //
           s2 >> nazwisko ;


   // wygodniej anonimowo ! <--- juz niemodne, wiec
   // nadaje temu stumieniowi nazwe s3

   istrstream s3(argv[3]);
   s3 >> z ;                              //

     cout << "Oto wartosci przyjetych parametrow\n"
          << x << endl
          << nazwisko << endl
          << z << endl
          << "suma tych liczb = " << (x+z) << endl ;



cout << "######## Nowy sposob ###############" << endl;

istringstream sn1(argv[1]) ;                               //
           sn1 >> x ;                                  //

istringstream sn2(argv[2]) ;                                 //
           sn2 >> nazwisko ;


   // wygodniej anonimowo ! <--- juz niemodne, wiec
   // nadaje temu stumieniowi nazwe s3

   istringstream sn3(argv[3]);
   sn3 >> z ;                              //

     cout << "Oto wartosci przyjetych parametrow\n"
          << x << endl
          << nazwisko << endl
          << z << endl
          << "suma tych liczb = " << (x+z) << endl ;


}





/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;


// PRZESTARZALY
#include <strstream>   // <--- bo uzywamy istrstream

// NOWY SPOSOB
#include <sstream>   // <-- bo  uzywamy istringstream

------------------------------------------------------
Korzystamy tutaj z przestarzalej klasy
  istrstream
podczas gdy powinnismmy tu juz uzyc
  istringstream

Dodatkowo anonimowe strumenie - nie weszly do
standardu. Nie ma czego zalowac, nowa klasa istringstream
jest naprawde bardzo wygodna.


Druga czesc programu pokazuje to samo z uzyciem
nowoczesniejszyej klasy.

------------------------------------------------------
int main()
------------------------------------------------------



Oprocz starego sposobu, do ktorego nowy standard juz
zniecheca - (choc ciagle akceptuje) pokazuje tu
lepszy sposob - z uzyciem klasy o nazwie ostringstream


  cout << "############## NOWY sposob ##############" << endl;


string schowek2("7.15 wtorek") ;   // <-- NOWY TYP, string
istringstream potok2(schowek2 );           // NOWYA LEPSZA KLASA,



W wypadku tej nowej, lepszej klasy  istringstream
tablica znakowa jest w obiektcie klasy strnig.
O tej klasie w "Syfmonii" nie rozmawialismy, ale
weszla juz na trwale do standardu.

(W nowych wydaniach "Symfonii C++" musi byc na ten
temat obszerny rozdzial).

-------------------------------------------------------

************************************************************/


