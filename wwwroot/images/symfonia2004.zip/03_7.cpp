//***************************************************
// Program z paragrafu  3.7 (str 45)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

int k = 33 ;          //  zmienna globalna (obiekt typu  int)
/*******************************************************/
int main()
{
     cout << "Jestem w main , k =" << k << "\n" ;
     {
          int k = 10 ;                    // zmienna lokalna
          cout << "po lokalnej definicji k ="
               <<     k                                        //
               << "\nale  obiekt globalny  k ="
               << ::k   ;                                   //
     }
     cout << "\nPoza blokiem k =" << k << endl ;

 }


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()
------------------------------------------------------


************************************************************/
