// ***************************************************
// Program z paragrafu   14.8.5 (str 372)
// ***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

#include <cstring>


/////////////////////////////////////////////////////////
class wizytowka {
public :
     char *nazw ;                                   //
     char *imie ;

     // konstruktor
     wizytowka(const char * na, const char * im) ;
     // destruktor
     ~wizytowka() ;

     void personalia() {
          cout << imie << " " << nazw << endl ;
     }
     //-----------
     void zmiana_nazwiska(const char *nowe)
     {
          strcpy(nazw, nowe);
     }
} ;
/////////////////////////////////////////////////////////
// definicja konstruktora
wizytowka::wizytowka(const char *im, const char *na)
{
     nazw = new char [80] ;                      //
     if(na) strcpy(nazw, na) ;                          //

     imie = new char [80] ;
     if(im) strcpy(imie, im) ;
}
/*******************************************************/
// ------------- definicja destruktora ----
wizytowka::~wizytowka()
{
     delete [] nazw ;                                   //
     delete [] imie ;
}
/*******************************************************/
int main()
{
wizytowka fizyk( "Albert", "Einstein") ;                //
wizytowka kolega = fizyk ;                             //


     cout << "Po utworzeniu blizniaczego obiektu oba "
               "zwieraja nazwiska\n" ;

     fizyk.personalia();                              //
     kolega.personalia();

     // m�j kolega nazywa sie naprawde Albert Metz

     kolega.zmiana_nazwiska("Metz");                    //

     cout << "\nPo zmianie nazwiska kolegi brzmi ono : ";
     kolega.personalia();                              //

     cout << "Tymczasem niemodyfikowany fizyk"
               " nazywa sie : " ;
     fizyk.personalia();                              //

}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <cstring>
------------------------------------------------------
      ~wizytowka() ;

W deklaracji destruktora - w ciele klasy niepotrzebniy
byl kwalifikator wizytowka::
Nie jest to blad, ale poco tu pisac rzecz oczywista.

------------------------------------------------------
     wizytowka(const char * na, const char * im) ; <---- 2X  const

Zmiany te sa zarowno w deklaracji jak i w definicji tej funkcji.

   void zmiana_nazwiska(const char *nowe)   <----  const

Dodany jest przydomek const, za kazdym razem z tego samego powodu:
Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*

-----------------------------------------------------
      nazw = new char [80] ;                      //
     if(na) strcpy(nazw, na) ;             // <----- dodane sprawdzenie if

     imie = new char [80] ;
     if(im) strcpy(imie, im) ;   // <----- dodane sprawdzenie if

bo gdybyw wskaznik txt mial wartosc zero, to funkcja strcpy wywolaby  blad pamieci
-----------------------------------------------------
int main()
------------------------------------------------------
wizytowka::~wizytowka()
{
     delete [] nazw ;                                   //
     delete [] imie ;
}

  Poniewaz rezerwacji w konsturktorze dokonywalismy operatorem new []
  wiec zwolnic te pamiec nalezy odpowiednio operatorem delete []

------------------------------------------------------
Jeszcze jedna uwaga. Otoz poniewaz w tym, blednym przykladzie
doprowadzamy do tego ze wskazniki obu obiektow pokazuja na te
same tablice - zatem w trakcie destrukcji tych obietkow
nastapia komplikacje. Pierwszy niszczony obiekt skasuje
rezerwacje tych tablic. Drugi oczywiscie musi zrobic to samo,
a poniewaz jego wskazniki pokazuja na te same tablice
wiec dojdzie do rzeczy zabronionej - czyli do powtornego
kasowania tej samej rezerwacji pamieci. 
Zatem na samo pozegnanie - program moze jeszcze zglosic blad pamieci.



************************************************************/
