//***************************************************
// Program z paragrafu   15.2.2 (str 383)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream>
using namespace std ;

#include <cstring>


///////////////////////////////////////////////////////
class stacje_metra2 {
     float km ;          // na ktorym kilometrze trasy
     int glebokosc ;
     char nazwa[40] ;
     char przesiadki[80];
public:
     // ---------- konstruktor                                    //
     stacje_metra2(float kk, int gg, const char *nn, const char *pp = "") ;
     // ---------- konstruktor domniemany
     stacje_metra2() ;
     // ---------- zwykla funkcja skladowa
     void gdzie_jestesmy() ;

} ;
//////////////////////////////////////////////////////
stacje_metra2::stacje_metra2(float kk, int gg, const char *nn, const char *pp)

               : km(kk), glebokosc(gg)             //
{
     if(nn) strcpy(nazwa, nn);
     if(pp) strcpy(przesiadki, pp) ;
}
/****************************************************/
stacje_metra2::stacje_metra2()
                                   // konstruktor domniemany
{
     km = 0 ;
     glebokosc = 0 ;
     strcpy(nazwa, "Nie nazwana jeszcze" );
     przesiadki[0] = 0 ;    // znak null
}
/****************************************************/
void stacje_metra2::gdzie_jestesmy()                    //
{
     cout << "Stacja : " << nazwa << endl ;

     if(przesiadki[0])     // to samo co:
                         // if(przesiadki[0] != NULL)
     {
          cout << "\tPrzesiadki : " << przesiadki << endl;
     }
}
/******************************************************/
int main()
{                                                        //
stacje_metra2 ostatnia =
               stacje_metra2 (22, 0, "Wansee", "118 Bus" );

     ostatnia.gdzie_jestesmy() ;
     cout << "********************\n" ;

const int ile_stacji = 7 ;
stacje_metra2 przystanek[ile_stacji] =       //

     {
     stacje_metra2 (0,  5, "Fredrichstrasse", "Linia U6"),
     stacje_metra2 (),
     stacje_metra2 (),
     stacje_metra2 (5.7, 4, "Tiergarten"),
     stacje_metra2 (8,   4, "ZOO", "Linie U1 i U9")
     } ;

     for(int i = 0 ; i < ile_stacji ; i++)
     {
          przystanek[i].gdzie_jestesmy() ;
     }
}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <cstring>
------------------------------------------------------
     przesiadki[0] = 0 ;    // znak null

znaku null unika sie bo to jest tzw. makro. Teraz pisze sie po prostu zero
(taki kod ma ten znak null)

------------------------------------------------------
stacje_metra2::stacje_metra2(float kk, int gg, const char *nn, const char *pp)   <---- 2X  const

Zmiany te sa zarowno w deklaracji jak i w definicji tej funkcji.


Dodany jest przydomek const, za kazdym razem z tego samego powodu:
Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*

-----------------------------------------------------
    if(nn) strcpy(nazwa, nn);                           // <----- dodane sprawdzenie if
     if(pp) strcpy(przesiadki, pp) ;           // <----- dodane sprawdzenie if



bo gdybyw wskaznik nn lub pp mial wartosc zero, to funkcja strcpy wywolaby  blad pamieci
-----------------------------------------------------
int main()
------------------------------------------------------



************************************************************/
