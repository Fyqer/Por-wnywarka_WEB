//***************************************************
// Program z paragrafu   20.10 (str 584)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

///////////////////////////////////////////////////////
class strunowy{                                        //
public :
     int liczba_lat ;
     // ...
     strunowy() : liczba_lat(0)     // kostruktor domniemany
     { }
     //--------------------
     virtual strunowy * nowy_dziewiczy() = 0 ;
     virtual strunowy * nowy_wzorowany() = 0 ;
     //---------------------
     virtual void jestem() = 0 ;
};
///////////////////////////////////////////////////////
class skrzypce : public strunowy {                    //
     // ...
     virtual strunowy * nowy_dziewiczy( )               //
     {
           return new skrzypce() ;     // wywolaj konstr domniemany
     }
     //---------------------
     virtual strunowy * nowy_wzorowany()
     {
           return new skrzypce(*this);// wywolaj konstr. kopiujacy
     }
     //---------------------
public:
     void jestem()
     {
          cout << "Jestm klasy skrzypce, mam lat = "
               << liczba_lat << endl ;
     }
};
///////////////////////////////////////////////////////
class wiolonczela : public strunowy {
     // ...
     virtual strunowy * nowy_dziewiczy()
     {
           return new wiolonczela() ;// wywolaj konstr domniemany

     }
     //---------------------
     virtual strunowy * nowy_wzorowany()
     {
       return new wiolonczela(*this);// wywolaj konstr. kopiujacy

     }
     //---------------------
public:
     void jestem(){
          cout << "Jestm klasy wiolonczela, mam lat = "
               << liczba_lat << endl ;
     }
};
////////////////////////////////////////////////////////
int main()                                            //

{
     skrzypce           skrz ;
     wiolonczela     wiol ;

     wiol.liczba_lat = 157 ;          // niech bedzie tak stara

     skrz.jestem();
       wiol.jestem();
     cout << "Teraz bedziemy wirtualnie konstruowac "
                    "dodatkowe obiekty\n" ;
     strunowy * wskaznik ;                              //
     wskaznik = &skrz ;                                   //

     strunowy * wsk1 ;                                   //
     wsk1 = wskaznik->nowy_dziewiczy();               //

     // wskaznik pokazywal na skrzypce wiec przekonajmy sie czy to

     // powstaly na prawde skrzypce.
     wsk1->jestem();                                   //
     //-----------------------
     wskaznik = &wiol ;                                   //

     strunowy * wsk2 = wskaznik->nowy_dziewiczy(); //

     wsk2->jestem();

     // nastepna tak kreowana wiolonczela niech bedzie
     // dokladna kopia tej starej

     strunowy * wsk3 = wskaznik->nowy_wzorowany(); //

     wsk3->jestem();

     delete wsk1 ;                                            //
     delete wsk2 ;
     delete wsk3 ;
}
/*****************************************************/




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------

------------------------------------------------------
int main()
------------------------------------------------------



************************************************************/


