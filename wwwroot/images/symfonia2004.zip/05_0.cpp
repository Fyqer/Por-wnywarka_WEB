//***************************************************
// Program z paragrafu  5.0 (str 75)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0



#include <iostream>
using namespace std ;


     int kukulka(int ile);                              //
     /**************************************************/
     int   main()
     {
     int m = 20 ;
          cout << "Zaczynamy" << endl ;

          m = kukulka(5) ;                              //
          cout << "\nNa koniec m = " << m ;               //


     }
     /**************************************************/
     int kukulka(int ile)                              //
     {                                                  //
     int i ;
          for(i = 0 ; i < ile ; i++)
          {
               cout << "Ku-ku ! " ;
          }
          return 77 ;                                   //
     }                                                  //



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()
------------------------------------------------------



************************************************************/
