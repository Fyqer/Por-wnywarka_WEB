//***************************************************
// Program z paragrafu   21.16 (str 660)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;
#include <fstream>

/*******************************************************/
int main()
{
char plik_a[80] ;
char plik_b[80] ;

     // ------------------------------------------------
     cout << "Podaj nazwe pliku wejsciowego : " ;
     cin >> plik_a ;
     ifstream czyt(plik_a) ;                           //
     if(!czyt){
               cout << "Nie moge otworzyc takiego pliku ";
               return 1 ;
     }
     // ------------------------------------------------
     cout << "Podaj nazwe pliku wyjsciowego : " ;
     cin >> plik_b ;

     ofstream pisz(plik_b) ;                         //
     if(!pisz){
               cout << "Nie moge otworzyc takiego pliku ";
               return 1 ;
     }
     // ----- akcja przepisywania ----------------------
     char c ;
     while(czyt.get(c)){                               //
          if(!pisz.put(c) ){                           //
               cout << "Blad pisania ! \n" ;
               break ;
          }
     }
     // -------- koniec, spr pow�d zakonczenia ---------
     if(!czyt.eof() ){                                 //
                 cout << "Blad czytania\n" ;
     }
}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <fstream>
------------------------------------------------------
int main()
------------------------------------------------------

************************************************************/


