//***************************************************
// Program z paragrafu  2.3 (str 18)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0




#include <iostream>
using namespace std ;
int main()
{
int ile ;

     cout << "Ile gwiazdek ma miec kapitan ? : " ;
     cin >> ile ;

     cout << "\n No to narysujmy wszystkie "
          << ile << " :  " ;

     // petla while rysujaca gwiazdki
     while(ile)
     {
          cout << "*" ;
          ile = ile - 1 ;
     }
     // na dowod ze mial prawo przerwac petle
     cout << "\n Teraz zmienna ile ma wartosc " << ile ;


 }


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()
------------------------------------------------------


************************************************************/
