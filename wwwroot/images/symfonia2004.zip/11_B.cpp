//***************************************************
// Program z paragrafu   11.b (str 309)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;

#include <cstring>


//---------------------------
class punkt ;                // deklaracja zapowiadajaca

/////////////////////////////////////////////////////////
class kwadrat  {
     int  x, y,
          bok ;
     char nazwa[30] ;
public :
     kwadrat(int a, int b, int dd, const char *opis) ;
     // ... moze cos jeszcze ...

     int sedzia (punkt & p) ;                         //
} ;
/////////////////////////////////////////////////////////
class punkt {
     int  x, y ;
     char nazwa[30] ;
public :
     punkt(int a, int b,const char *opis) ;
     void ruch(int n, int m)  { x += n ; y += m ; }
     // ... moze cos jeszcze ...

     friend int kwadrat::sedzia(punkt & p) ;             //
} ;
////////////////////////////////////////////////////////
punkt::punkt(int a, int b,const char *opis)     // konstruktor
{
     x = a ; y = b ;
     if(opis)       strcpy(nazwa, opis) ;
     else         nazwa[0] = 0 ; // pusty string
}
/*******************************************************/
kwadrat::kwadrat(int a, int b, int dd, const char *opis)
                                             // konstruktor
{      x = a ; y = b ;
     bok = dd ;
     if(opis)       strcpy(nazwa, opis) ;
     else         nazwa[0] = 0 ; // pusty string

}
/******************************************************/
int kwadrat::sedzia (punkt & pt)                     //

{
     if( (pt.x >= x)  && (pt.x <= (x + bok) )       //

          &&
           (pt.y >= y)  && (pt.y <= (y + bok) )
       )
     {
          cout << pt.nazwa << " lezy na tle "
               << nazwa << endl ;
          return 1 ;
     }else {
          cout << "AUT ! " << pt.nazwa
               << " jest na zewnatrz "
               << nazwa << endl ;
          return 0 ;
     }
}
/*******************************************************/
int main()
{
     kwadrat     bo(10,10, 40, "boiska") ;
     punkt     pi( 20, 20, "pilka");
     bo.sedzia(pi);                                    //

}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <cstring>

------------------------------------------------------

punkt::punkt(int a, int b,const char *opis)     // konstruktor  <--- dodane const
{
     x = a ; y = b ;
     if(opis)       strcpy(nazwa, opis) ;    <--- dodane sprawdzenie
     else         nazwa[0] = 0 ; // pusty string
}

oraz

kwadrat::kwadrat(int a, int b, int dd, const char *opis) <--- dodane const
                                             // konstruktor
{      x = a ; y = b ;
     bok = dd ;
     if(opis)       strcpy(nazwa, opis) ;      <--- dodane sprawdzenie
     else         nazwa[0] = 0 ; // pusty string

}

w deklaracji i definicji tych konstruktorow dodany jest
przydomek "const"
Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*

-  A TAKZE ------------

Dodane zostalo sprawdzenie
czy wskaznik do stringu nie pokazuje czasem na adres 0 (NULL).
Gdyby tak bylo, to funkcja strcpy spowodowalaby blad pamieci.
Zatem najpierw to sprawdzamy, a jesli ta, to do tablicy
wpisujemy 0 do zerowego elementu, co odpowiada pustemu stringowi

------------------------------------------------------
int main()
------------------------------------------------------



-------------------------------------------------------

************************************************************/
