//***************************************************
// Program z paragrafu  4.1.3 (str 58)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream>
using namespace std ;

int main()
{
     int      a = 5,
          b = 5,
          c = 5,
          d = 5 ;

          cout << "A oto wartosc poszczegolnych wyrazen\n"
               << "(nie mylic ze zmiennymi)\n" ;

          cout << "++a = " << ++a << endl
               << "b++ = " << b++ << endl
               << "--c = " << --c << endl
               << "d-- = " << d-- << endl ;

          // teraz sprawdzamy co jest obecnie w zmiennych

          cout << "Po obliczeniu tych wyrazen, same "
                    "zmienne maja wartosci\n"
               << "a = " << a << endl
               << "b = " << b << endl
               << "c = " << c << endl
               << "d = " << d << endl ;

 }


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()


************************************************************/
