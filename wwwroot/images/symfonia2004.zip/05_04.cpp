//***************************************************
// Program z paragrafu  5.4 (str 83)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

void zer( int wart, int &ref);//
/******************************************************/
int main()
{
int a = 44,
     b = 77 ;

     cout <<  "Przed wywol funkcji: zer \n" ;
     cout << "a = " << a << ", b = " << b  << endl ;

     zer(a, b) ;                                        //

     cout <<  "Po powrocie z funkcji: zer \n" ;
     cout << "a = " << a << ", b = " << b  << endl ; //

}
/******************************************************/
void zer( int wart, int &ref)
{
     cout <<  "\tW funkcji zer przed zerowaniem \n"     ;
     cout << "\twart = " << wart << ", ref = "
           << ref  << endl ;                          //

     wart = 0 ;
     ref  = 0 ;                                        //

     cout <<  "\tW funkcji zer po zerowaniem \n"  ;
     cout << "\twart = " << wart << ", ref = "
           << ref  << endl ;                          //

}                                                       //



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()
------------------------------------------------------



************************************************************/
