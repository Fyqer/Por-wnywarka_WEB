//***************************************************
// Program z paragrafu  5.1 (str 78)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;


long potega(int stopien, long liczba) ;
/******************************************************/
int   main()
{
int pocz, koniec ;

     cout << "Program na obliczanie poteg liczb"
          << "calkowitych\n"
          << "z zadanego przedzial \n"
          << "Podaj poczatek przedzialu : ";
     cin >> pocz ;

     cout << "\nPodaj koniec przedzialu : " ;
     cin >> koniec ;

     // petla drukujaca wyniki z danego  przedzialu
     for(int i = pocz ; i <= koniec ; i++)
     {
          cout << i
               << "  do kwadratu = "
               << potega(2, i)                 // wywol funkcji
               << "  a do szescianu = "
               << potega(3, i)                  // wywol funkcji
               << endl ;
     }



}
/*****************************************************/
long potega(int stopien, long liczba)
{
long wynik = liczba ;
     for(int i = 1 ; i < stopien ; i++)
     {
          wynik = wynik * liczba ;
                    // zwiezlej mozna zapisac to samo jako  :
                    //          wynik *= liczba ;
     }
     return wynik ; //
}
/*****************************************************/



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()
------------------------------------------------------



************************************************************/
