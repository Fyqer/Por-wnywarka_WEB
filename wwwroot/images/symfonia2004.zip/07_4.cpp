//***************************************************
// Program z paragrafu  7.4 (str 138)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;


     int main()
     {
     char napis1[] = { "Nocny lot"} ;
     char napis2[] = { 'N', 'o', 'c', 'n', 'y',
                         ' ', 'l', 'o', 't' } ;
          cout << "rozmiar tablicy pierwszej : "
               << sizeof(napis1) << endl ;

          cout << "rozmiar tablicy drugiej : "
               << sizeof(napis2) << endl ;

     }




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()

------------------------------------------------------



************************************************************/
