//***************************************************
// Program z paragrafu   10.16 (str 299)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;

#include <cstring>

enum tak_czy_nie { nie, tak } ;                         //
////////////////////////////////////////////////////////
class piorko {
     int poz_x, poz_y ;
     static int zezwolenie ;                            //
     char kolor[30] ;

     // funkcje ------------------------------------------------------------
public :
     void jazda(int x , int y)
     {
          cout << "Tu "<< kolor << " piorko : " ;
          if(zezwolenie){                               //
               poz_x = x ;
               poz_y = y ;
               cout << "Jade do punktu ("
               << poz_x  << ", " << poz_y << ")\n" ;
          }
          else
          {
           cout <<
               "     Nie wolno mi jechac !!!!!!!!!!!!! \n" ;
          }
     }
     //--------------------------------------------------


     static void mozna(tak_czy_nie odp)
     {
          zezwolenie = odp ;          // skladnik statyczny
          // poz_x = 5 ;      // blad ! bo skladnik zwykly

     }
     // ---------------------------------------------

     piorko(const char * kol)
     {
          if(kol)strcpy(kolor, kol);
          else kolor[0] = 0 ;

          poz_x = poz_y = 0 ;
     }
};
/////////////////////////////////////////////////////////
int piorko::zezwolenie ;
/******************************************************/
int main()
{
     piorko::mozna(tak) ;                              //

     piorko czarne("SMOLISTE"), zielone("ZIELONIUTKIE") ;
     czarne.jazda(0, 0) ;
     zielone.jazda(1100, 1100) ;

     // zabraniamy ruchu piorkom
     piorko::mozna(nie) ;

     czarne.jazda(10, 10) ;
     zielone.jazda(1020, 1020) ;

     // zezwalamy w taki sposob
     zielone.mozna(tak);                                //
     czarne.jazda(50, 50) ;
     zielone.jazda(1060, 1060) ;

}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <cstring>
------------------------------------------------------

     piorko(const char char * kol)

   Dodany jest przydomek cons.

Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*


------------------------------------------------------
W tym samym konstruktorze

if(kol)strcpy(kolor, kol);
else kolor[0] = 0 ;

dodane zostalo sprawdzenie
czy wskaznik do stringu nie pokazuje czasem na adres 0 (NULL).
Gdyby tak bylo, to funkcja strcpy spowodowalaby blad pamieci.
Zatem najpierw to sprawdzamy, a jesli ta, to do tablicy kolor
wpisujemy 0 do zerowego elementu, co odpowiada pustemu stringowi


------------------------------------------------------
int main()

-------------------------------------------------------

************************************************************/
