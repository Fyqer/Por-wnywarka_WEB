//***************************************************
// Program z paragrafu   19.2.1 (str 499)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;

/////////////////////////////////////////////////////////
// klasa podstawowa
/////////////////////////////////////////////////////////
class ryba {
private :
     int a ;
protected:
     int prots ;
public:
     int pubs ;

     void wstaw(int m ) { a = m ; }
     int czytaj()  { return a ; }
};
/////////////////////////////////////////////////////////
// klasa pochodna
/////////////////////////////////////////////////////////
class rekin : public ryba {
     float x ;
public :
     void funk();
} ;
/*******************************************************/
void rekin::funk()
{
     x = 15.6 ;                                        //
     //a = 6 ;                                         //
     wstaw(6) ;                                          //
     cout << "\n wyjety funkcja 'czytaj' skladnik a="
          << czytaj() ;                                //
     prots = 77 ;                                         //
     pubs = 100 ;
     cout << "\n bezposr. odczytany skladnik protected = "
          << prots
          << "\n bezposr. odczytany skladnik public  = "
          << pubs  ;
}
/*******************************************************/
int main()
{
rekin wacek ;
     wacek.funk() ;
}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;


-----------------------------------------------------
int main()
------------------------------------------------------



************************************************************/


