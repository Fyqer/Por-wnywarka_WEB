//***************************************************
// Program z paragrafu   20.9 (str 579)
//***************************************************

// Sprawdzony na Linuksie,    kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
// ???????????????????????????????????????????????????????


#include <iostream>
using namespace std ;

#include <cstring>
/////////////////////////////////////////////////////////
class instrum {
public :
      virtual void wydaj_dzwiek()      {
          cout << "cisza" ;
     }
     // ----wirtualny destruktor
     virtual ~instrum()                                  //
     {
          cout << "Destruktor instrumentu \n" ;

     }
} ;
/////////////////////////////////////////////////////////
class skrzypce : public instrum {                         //
     char *nazwa ;
public :
     // - konstruktor------------------------

     skrzypce(const char *firma)
     {
          nazwa = new char[strlen(firma) + 1] ;         //
          if(firma) strcpy(nazwa, firma) ;
     }
     //- destruktor (wirtualny) -----------------

     ~skrzypce()
     {
          cout << "Destruktor skrzypiec + " ;
          delete [] nazwa ;                              //
     }
     // ----------------------------

     void wydaj_dzwiek()
     {
          cout << "tirli-tirli ("
               << nazwa << ")\n" ;
     }
} ;
/////////////////////////////////////////////////////////
class gwizdek :public instrum {                         //
public :
     void wydaj_dzwiek()     {
          cout << "fiu-fiu \n" ;
     }
} ;
/////////////////////////////////////////////////////////
class gitara : public instrum {
     char *nazwa ;
public :
     // - konstruktor-------------------

     gitara(const char *firma)
     {
          nazwa = new char[strlen(firma) + 1] ;       //
          strcpy(nazwa, firma) ;
     }
     //- destruktor (wirtualny) ---------------

     ~gitara()
     {
          cout << "Destruktor gitary + " ;
          delete [] nazwa ;                                //
     }
     // --------------------------

     void wydaj_dzwiek()
     {
          cout << "brzdek-brzdek   ("
               << nazwa << ")\n" ;
     }
} ;
/*******************************************************/
int main()
{
     cout << "Definiujemy w zapasie pamieci\n"
               "trzy instrumenty orkiestry\n  " ;

     instrum *pierwszy = new skrzypce("Stradivarius") ;
     instrum *drugi    = new gitara("Ramirez") ;
     instrum *trzeci   = new gwizdek ;                 //

     cout << "Gramy polimorficznie ! \n" ;

     pierwszy->wydaj_dzwiek() ;                         //
     drugi   ->wydaj_dzwiek() ;
     trzeci  ->wydaj_dzwiek() ;

     cout << "\nKoncert sie skonczyl, "
               "likwidujemy instrumenty\n\n" ;

     delete pierwszy ;                                   //
     cout << "******************\n" ;
     delete drugi ;
     cout << "******************\n" ;
     delete trzeci ;
}
/*******************************************************/




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------
     virtual void wydaj_dzwiek()                         //

Slowko virtual bylo dopiero po void!
-------------------------------------------------------
     skrzypce(const char *firma)   <--- dodane const
     {
          nazwa = new char[strlen(firma) + 1] ;         //
          if(firma) strcpy(nazwa, firma) ; <-- dodane if
     }
PODOBNIE
     gitara(const char *firma)  <--- dodane const
     {
          nazwa = new char[strlen(firma) + 1] ;       //
          strcpy(nazwa, firma) ; <-- dodane if
     }

Dodany jest przydomek const, za kazdym razem z tego samego powodu:
Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*

Optymistyczna uwaga: od czasu, gdy do biblioteki standardowej weszla standardowa klasa
"class string", nastapilo ogromne uproszczenie i takich konstrukcji stosowac juz nie trzeba.

DRUGA SPRAWA :
dodane sprawdzenie if czy wskaznik do stringu nie pokazuje
czasem na adres 0 (NULL).
Gdyby tak bylo, to funkcja strcpy spowodowalaby blad pamieci.

------------------------------------------------------
int main()
------------------------------------------------------

W destruktorach ~skrzypce()  ~gitara()

  delete [] nazwa ;    // <---- dodane []


************************************************************/


