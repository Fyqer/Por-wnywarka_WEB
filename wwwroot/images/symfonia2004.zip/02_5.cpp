//***************************************************
// Program z paragrafu  2.5 (str 21)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream>
using namespace std ;
int main()
{
int  i ,               // licznik
     ile ;          // liczba pasazer�w

     cout << "Stewardzie, ilu leci pasazerow ? " ;
     cin >> ile ;

     for(i = 1 ; i <= ile ; i = i + 1)
     {
          cout << "Pasazer nr " << i
               << " prosze zapiac pasy ! \n" ;
     }
     cout << "Skoro wszyscy juz zapieli, to ladujemy. " ;

 }


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()
------------------------------------------------------


************************************************************/
