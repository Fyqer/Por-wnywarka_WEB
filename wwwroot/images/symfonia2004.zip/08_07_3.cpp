//***************************************************
// Program z paragrafu   8.7.3 (str 168)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;


//****************************************************
int main()
{
int tablica[15] ;          // definicja tablicy
int *wsk_a, *wsk_b, *wsk_c ;

     wsk_a = &tablica[5] ;
     wsk_b = &tablica[10] ;
     wsk_c = &tablica[11] ;

     cout << "(wsk_b - wsk_a) = "    << (wsk_b - wsk_a)
          << "\n(wsk_c - wsk_b) = "  << (wsk_c - wsk_b)
          << "\n(wsk_a - wsk_c) = "  << (wsk_a - wsk_c)
          << "\n(wsk_c - wsk_a) = "  << (wsk_c - wsk_a) ;

}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------

int main()


************************************************************/
