//***************************************************
// Program z paragrafu  2.2 (str 17)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0




#include <iostream>
using namespace std ;
int main()
{
int wys, punkty_karne ;        // definicja dw�ch zmiennych
          // typu int. Obie sa tego samego typu wiec
          // wystarczy przecinek odzielajacy nazwy

     cout << "Na jakiej wysokosci lecimy ? [w metrach] : ";
     cin >> wys ;

     // rozwazamy sytuacje ------------------------
     if(wys < 500)
     {
          cout << "\n" << wys << " metrow to za nisko !\n";
          punkty_karne = 1 ;
     }
     else
     {
          cout << "\nNa wysokosci " << wys
               << " metrow jestes juz bezpieczny \n" ;
          punkty_karne = 0 ;
     }

     // ocena Twoich wynikow -----------------------
     cout << "Masz " << punkty_karne
          << " punktow karnych \n" ;
     if(punkty_karne)cout << "Popraw sie !" ;

 }


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()



************************************************************/
