//***************************************************
// Paragraf  22.8.5 (str 723)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

#include <iomanip>
#include <fstream>
#include <cstring>

#include <cctype>          // dla tolower();



void wyczysc_ekran(); // deklaracja funkcji mazacej ekran

fstream plik ;

enum typy_blokow { mlyn = 1, expr, napi, skal, jedn, matr };
/********************************************************************/
const int ile_kaset = 5 ;
const int ile_szufladek = 20 ;
//////////////////////////////////////////////////////////////////////
class blok {
public:
     // funkcje skladowe
     virtual void rozmowa() = NULL;               // pure virtual
     virtual void zapisz_sie()= NULL;
     virtual void odtworz_sie()= NULL;
     virtual const char * kto_jestes() ;
     virtual ~blok() ;
} ;
//////////////////////////////////////////////////////////////////////
inline const char * blok::kto_jestes() {
     return "bez nazwy" ;
}
/*-----------------------------------*/
inline blok::~blok()          // wirtualny destruktor
{
     cout << "destruktor z klasy blok ! " << endl ;
}

/*********************************************************************/
class kaseta {

     blok * szufladka[ile_szufladek] ;      // tablica wskaznikow
     int akt_sz ;                           // nr wlasnie wybranej szufladki

public:
     // funkcje skladowe
     kaseta () ;                           // konstruktor
     void narysuj_sie();                   // rysowanie kasety
     void zapisz_bloki();                  // zapis blokow kasety
     void czytaj_blok() ;                  // odczyt blok�w
     void edycja() ;                       // bedzie regulacja
     int akt() ;                           // aktywna szufladka
     void wybierz(int n) ;                 // sklepik ?
     void skasuj() ;                       // wyrzucanie bloku
     void wstaw() ;                        // wstawianie bloku

     void stworca(int nr) ;                // pomocnicza funkcja
} ;
/********************************************************************/
kaseta::kaseta ()          // konstruktor
{
     for(int i = 0 ; i  < ile_szufladek ; i++){
          szufladka[i] = NULL ;
     }
     akt_sz = 0 ;
     cout << "konstruktor kasety " << endl ;

}
/********************************************************************/
void kaseta::narysuj_sie()
{

char linijka[80] = {""};

     //delay(500) ;
     wyczysc_ekran();

     // rysujemy w poziomie
     for(int i=0 ; i <= ile_szufladek ; i++){
          strcat(linijka,"---") ;  ;
     }

     // wykrzyknik przy wybranej kasecie
     linijka[3 * akt_sz + 2] = '!' ;
     cout << linijka << endl ;

     for(int wys = 0 ; wys < 5 ; wys++)
     {
          cout << "I " ;
          for(int i = 0 ; i < ile_szufladek ; i++)
          {
               cout <<
                    (      (szufladka[i] != NULL ) ?
                         *( (szufladka[i]->kto_jestes())+wys)
                    :
                      ' '
                    )
                    << ". " ;
          }
          cout << 'I' << endl ;

     }
     // linijka[3*akt_sz + 2] = '^' ;
     cout << linijka << endl ;

     for(int i=0 ; i < ile_szufladek ; i++){
          cout << setw(3) << i ;

     }
     cout << endl ;
}
/*-----------------------------------*/
void kaseta::czytaj_blok(){                // tu jest polimorfizm
     szufladka[akt_sz] -> odtworz_sie() ;
}
/*-----------------------------------*/
void kaseta::edycja(){
     if(szufladka[akt_sz]) {
               szufladka[akt_sz] -> rozmowa();
     }
}
/*-----------------------------------*/
int kaseta::akt() { return akt_sz ; }
/*-----------------------------------*/
void kaseta::wybierz(int n) { akt_sz = n ; }
/*-----------------------------------*/
void kaseta::skasuj() {
     if(szufladka[akt_sz]){
          delete szufladka[akt_sz] ;
          szufladka[akt_sz] = NULL ;
     }
}
//////////////////////////////////////////////////////////////////////
class wieza {
     kaseta   k[ile_kaset] ;          // piec obiektow klasy kaseta
     int akt_ka ;                        // nr aktywnej kasety
public:
     // funkcje skladowe
     wieza();
     void wybierz(int nr);
     void wyb_szuf(int nr) ;
     int ktora_szufladka() ;
     int ktora_kaseta() ;
     void zapis() ;
     void odczyt();
     void regulacja() ;
     void narysuj() ;
     void usun() ;
     void dodaj() ;
} ;
/********************************************************************/
wieza::wieza() {
     akt_ka = 0 ;      // konstruktor ??
     cout << "konstr wiezy" << endl ;
}
/*-----------------------------------*/
void wieza::wybierz(int nr)
{
     akt_ka = nr ;   // aktywowanie jednej z kaset
}
/*-----------------------------------*/
void wieza::wyb_szuf(int nr)
{
     k[akt_ka].wybierz(nr) ;   // aktywowanie jednej z kaset
}
/*-----------------------------------*/
int wieza::ktora_szufladka()
{
     return (k[akt_ka].akt()) ;
}
/*-----------------------------------*/
int wieza::ktora_kaseta() { return akt_ka ; }
/*-----------------------------------*/
void wieza::regulacja() {
     k[akt_ka].edycja();
}
/*-----------------------------------*/
void wieza::narysuj() {
     k[akt_ka].narysuj_sie() ;
}
/*-----------------------------------*/
void wieza::usun() {
     k[akt_ka].skasuj();
}
/*-----------------------------------*/
void wieza::dodaj(){
     k[akt_ka].wstaw();
}
/*--------------------------------------------------------------------*/
void kaseta::zapisz_bloki()
{
     for(int i = 0 ; i < ile_szufladek ; i++)
     {
          if(szufladka[i]){
               plik << "\tszufladka\t" << i << endl ;
                      // nr indentyfikacyjny juz konkretnie w bloku
               szufladka[i]->zapisz_sie() ;
          }
     }
}
/********************************************************************/
void wieza::zapis()
{

     // otwarcie pliku
     plik.open("t.sav", ios::out);

     // zapis tresci poszczegolnych kaset
     for(int i = 0 ; i < ile_kaset ; i++)
     {
          plik << "Kaseta  " << i <<endl ;
          k[i].zapisz_bloki();
     }
     // zamkniecie pliku
     plik.close();
     // zrobic gdzies obsluge bledow
     if(!plik){
          cout << "\aBlad w trakcie pisania pliku" ;
     }
}
//////////////////////////////////////////////////////////////////////
class menu {

     wieza *wiezyczka ;
public:
     menu(wieza *x) ;
     void narysuj_menu();
     int wybor_opcji();
} ;
/********************************************************************/
menu::menu(wieza *x){
          wiezyczka =  x ;
          narysuj_menu();

}
/********************************************************************/
void menu::narysuj_menu()
{
     cout <<                          //"program do ustawiania elektroniki\n"
          "\n\n Biezaca wybrana jest : kaseta    nr "
          << wiezyczka->ktora_kaseta() <<
          " szufladka nr " ;
     cout << wiezyczka->ktora_szufladka() <<
          "\n\n"
          "                    k - wybierz inna kasete\n"
          "                    s - wybierz inna szufladke\n"
          " Opcje akcji \n"
          "      r - rozmawiaj\n"
          "      w - wstaw blok do tej szuflady\n"
          "      u - usun blok z tej szuflady\n"
          "      z - zapis wszystkiego na dysk\n"
          "      o - odczyt z dysku\n"
          "      x - zakoncz prace programu"<< endl ;

}
/*********************************************************************/
int menu::wybor_opcji()
{
char opcja ;
int i ;

           cin >> opcja ;
           switch(tolower(opcja))
           {
                case 'k' :
                     cout<< "Ktora kaseta ? : " ;
                     cin >> i ;
                     if(i >= 0  && i < 5){
                          wiezyczka->wybierz(i);
                     }else{
                          cout << "numer moze byc z zakresu 0 - 4 "
                                        "\a\nWcisnij Enter..." ;
                          cin >> i ;
                     }
                     break;
                case 's' :
                     cout<< "Ktora szuflada ? : " ;
                     cin >> i ;
                     if(i >= 0  && i < 20){
                         wiezyczka->wyb_szuf(i);
                     }else{
                          cout << "numer moze byc z zakresu 0 - 19 "
                                        "\a\nWcisnij Enter..." ;
                          cin >> i ;
                     }
                     break;
                case 'r' :
                     wiezyczka->regulacja();
                     break ;
                case 'z' :
                     wiezyczka->zapis();
                     break ;
                case 'o' :
                     wiezyczka->odczyt();
                     break ;
                case 'u' :
                     wiezyczka->usun();
                     break;
                case 'w' :
                     wiezyczka->dodaj();
                     break ;
                case 'x' :
                     return 0;
           } // end switch
           return 1 ; // wszystko oprocz x
}
//////////////////////////////////////////////////////////////////////
/////////// klasy konkretnych realizacji blokow //////////////////////
//////////////////////////////////////////////////////////////////////
class mlynek : public blok {
int grubosc ;

     // funkcje skladowe
     void miel();
public:
     // funkcje skladowe
     mlynek(){ grubosc = 5 ; }
     void rozmowa() ;
     void zapisz_sie() ;
     void odtworz_sie() ;
     const char * kto_jestes() ;
     ~mlynek() { cout << "destruktor mlynka" << endl ; }
} ;
/**********************************************************************/
void mlynek::zapisz_sie() {
     cout << kto_jestes() << " sie zapisuje" << endl ;
     plik << mlyn << endl ;
}
/*-----------------------------------*/
void mlynek::odtworz_sie()
{

     cout << kto_jestes() << " sie odtwarza" << endl ;
}
/*-----------------------------------*/
const char * mlynek::kto_jestes()
{
     return "mlynek" ;
}
/*-----------------------------------*/
void mlynek::rozmowa()
{
char co ;

     cout << kto_jestes() << " rozmawia " << endl ;
     while(1){
            wyczysc_ekran();
            cout << "JESTEM MLYNEK\nmiele z gruboscia: " << grubosc ;
            cout << "\nopcje mlynka -\n"
                           "     g - zmiana grubosc mielenia\n"
                           "     m - zmiel wsypana kawe\n"
                           "     x - koniec rozmowy\nCo robic ? : " ;
            cin >> co ;
            switch(tolower(co)){
                 case 'g' :
                      cout <<  "dotychczasowa grubosc mielenia byla: " << grubosc
                               <<  "\nPodaj nowy parametr grubosci [1-10] : " ;
                      cin >> grubosc ;
                      break ;
                 case 'm' :
                      cout << " m-m-m-m-m \n Juz zmielone !\n" ;
                      //sleep(2);
                      break ;
                 case 'x' :
                      return ;
            }
     }
}
//////////////////////////////////////////////////////////////////////
class express : public blok{
public:
     // funkcje skladowe
     void rozmowa() {
          cout << kto_jestes() << " rozmawia " << endl ;cin.get();
     }
     /*-----------------------------------*/
     void zapisz_sie(){
          cout << kto_jestes() << " sie zapisuje" << endl ;
          plik << expr << endl ;
     }
     /*-----------------------------------*/
     void odtworz_sie()
     {
          cout << kto_jestes() << " sie odtwarza" << endl ;
     }
     /*-----------------------------------*/
     const char * kto_jestes() { return "express" ; }

     // wirtualny destruktor
     ~express() {
          cout << "destruktor ekspresu " << endl ;
     }

};
//////////////////////////////////////////////////////////////////////
class wys_napiecie : public blok{
int zrodlo, wartosc ;

public:
     // funkcje skladowe
     // konstruktor
   wys_napiecie() : zrodlo(0), wartosc(0) {} ;
     void rozmowa() ;
     /*-----------------------------------*/
     void zapisz_sie() {
          cout << kto_jestes() << " sie zapisuje" << endl ;
          plik << napi << endl ;
     }
     /*-----------------------------------*/
     void odtworz_sie(){
          cout << kto_jestes() << " sie odtwarza" << endl ;
     }
     /*-----------------------------------*/
     const char * kto_jestes() { return "wys na" ; }
     /*-----------------------------------*/

     ~wys_napiecie() { cout << "destruktor w.n." << endl ; }
} ;
/**********************************************************************/
void wys_napiecie::rozmowa()
{
char co ;

     cout << kto_jestes() << " rozmawia " << endl ;
     while(1){
            wyczysc_ekran();
            cout << "      *** Blok Wysokiego Napiecia ***\n"
                           " obsluguje 256 zrodel wysokiego napiecia\n\n"
                           "\n\n\n"
                           " Biezaco wybrane zrodlo nr "
                           << zrodlo << "  ma napiecie " << wartosc << "\n\n\n"
                           "\nopcje bloku -\n"
                           "     n - wybierz inny numer zrodla \n"
                           "     u - ustaw wartosc jego napiecia\n"
                           "     x - zakoncz rozmowe\nCo robic ? : " ;
            cin >> co ;
            switch(tolower(co)){
                 case 'n' :
                      cout <<  "Podaj numer zrodla [1-24] : " ;
                      cin >> zrodlo ;
                      // dowiadujemy sie od razu jaka jest wartosc tego zrodla
                      // interface.komunikacja(kaseta, szufl, funkcja, &dana);
                      wartosc = 99 ; // na chama !
                      break ;
                 case 'u' :
                      cout << " Podaj zadana wartosc napiecia :" ;
                      cin >> wartosc ;
                      // wykonanie
                      // kounikacja z CAMAkiemem
                      break ;
                 case 'x' :
                      return ;
            }
     }
}

//////////////////////////////////////////////////////////////////////
class jednostka_logiczna  : public blok{
public:
     // funkcje skladowe
     void rozmowa() {
          cout << kto_jestes() << " rozmawia " << endl ;
          cin.get();
     }
     /*-----------------------------------*/
     void zapisz_sie() {
          cout << kto_jestes() << " sie zapisuje" << endl ;
          plik << jedn << endl;
     }
     /*-----------------------------------*/
     void odtworz_sie(){
          cout << kto_jestes() << " sie odtwarza" << endl ;
     }
     /*-----------------------------------*/
     const char * kto_jestes() { return "logic" ; }
     /*-----------------------------------*/
     ~jednostka_logiczna() {
          cout << "destruktor jednostki_logiczna" << endl ;
     }
} ;
//////////////////////////////////////////////////////////////////////
class matryca_opoznien : public blok{
public:
     // funkcje skladowe
     void rozmowa() {
          cout << kto_jestes() << " rozmawia " << endl ;
          cin.get();
     }
     /*-----------------------------------*/
     void zapisz_sie() {
          cout << kto_jestes() << " sie zapisuje" << endl ;
          plik << matr << endl;
     }
     /*-----------------------------------*/
     void odtworz_sie(){
          cout << kto_jestes() << " sie odtwarza" << endl ;
     }
     /*-----------------------------------*/
     const char * kto_jestes() { return "opozn" ; }

     // destruktor ---------------------------
     ~matryca_opoznien()
     {
          cout << "destruktor martrycy_opoznien" << endl ;
     }
} ;

//////////////////////////////////////////////////////////////////////
class skaler : public blok{
public:
     // funkcje skladowe
     void rozmowa() {
          cout << kto_jestes() << " rozmawia " << endl ;
          cin.get();
     }
     /*-----------------------------------*/
     void zapisz_sie() {
          cout << kto_jestes() << " sie zapisuje" << endl ;
          plik << skal << endl ;
     }
     /*-----------------------------------*/
     void odtworz_sie(){
          cout << kto_jestes() << " sie odtwarza" << endl ;
     }
     /*-----------------------------------*/
     const char * kto_jestes()  { return "skaler" ; }
     // -----------------------destruktor --------
     ~skaler() { cout << "destruktor skalera" << endl ; }
} ;
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
void kaseta::wstaw()
{
int nr ;
char c ;
     if(szufladka[akt_sz]) {
          cout << "szufladka jest zajeta\n\aWcisnij ENTER..." ;
     }
     cout << "Masz do wyboru takie bloki:\n"
                    "  1  -  mlynek do kawy\n"
                    "  2  -  ekspres do kawy\n"
                    "  3  -  blok wysokiego napiecia\n"
                    "  4  -  skaler\n"
                    "  5  -  jednostka logiczna\n"
                    "  6  -  matryca opoznien\n"
                    "  0  -  ZADEN Z POWYZSZYCH \n"
                    " ------ Podaj numer wstawianego bloku : " ;

     cin >> c ;
     if(!isdigit(c))return ;
     cin.putback(c);
     cin >> nr ;
     stworca( (typy_blokow) nr) ;
}
/***********************************************************/
void kaseta::stworca(int nr)
{
     switch(nr){
          default :
               cout << "nieznany blok" ;
               break ;
          case mlyn :
               szufladka[akt_sz] = new mlynek ;
               break ;
          case expr :
               szufladka[akt_sz] = new express ;
               break ;
          case napi :
               szufladka[akt_sz] = new wys_napiecie ;
               break ;
          case skal :
               szufladka[akt_sz] = new skaler ;
               break ;
          case jedn :
               szufladka[akt_sz] = new jednostka_logiczna ;
               break ;
          case matr :
               szufladka[akt_sz] = new matryca_opoznien;
               break ;
     } // switch
}
/********************************************************************/
void wieza::odczyt()
{
int sz ;           // lokalne nr kasety i szufladki
int typ ;
char wyraz[30] ;
     // otwarcie pliku
     plik.open("t.sav", ios::in);
                                                       // sukcesywne czytanie pliku
                                                       // i tworzenie wg tego wzoru
                                                       // odpowiednich blokow w odpowiednich
                                                       // miejscach
     while(plik){
          plik >> wyraz ;
          if(!plik)break ;

          if(strcmp(wyraz, "kaseta") == 0)
          {
               plik >> akt_ka ;
          }else if(strcmp(wyraz, "szufladka") == 0)
          {
               plik >> sz ;
               k[akt_ka].wybierz(sz) ;        // uaktywnienie tej szufladki
               cout << "czytam tresc - szufladki nr " << sz << endl ;
               plik >> typ  ;                         // ma byc ten typ
                                                            // kreacja bloku, ktory
                                                            // jeszcze nie istnieje
               k[akt_ka].stworca(typ);

                                                            // wczytanie parametrow wlasciwych
                                                            // danemu typowi bloku
                                                            // tu jest polimorfizm
               k[akt_ka].czytaj_blok();
          }
     }
     plik.close();
                                                            // zrobic gdzies obsluge bledow
     if(!plik){
          cout << "\aBlad w trakcie pisania pliku" ;
     }
}
//////////////////////////////////////////////////////////////////////
int main()
{
wieza w ;
menu m(&w) ;

     wyczysc_ekran();
     do {
           w.narysuj() ;
           m.narysuj_menu();
     }while ( m.wybor_opcji());

     return 1 ;  // poprawn progr
}
// **************************************************************
void wyczysc_ekran()
{
  cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" << endl;
}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <iomanip>
#include <fstream>
#include <cstring>

#include <cctype>          // dla tolower();


------------------------------------------------------
class express : public blok{
public:  <-- dodane

------------------------------------------------------
------------------------------------------------------
------------------------------------------------------

virtual const char * kto_jestes() ;

i we wszystkich dalszych defincjach/deklaracjach
tej funkcji virtualnej - pojawil sie przydomek const

Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*

Optymistyczna uwaga: od czasu, gdy do biblioteki standardowej weszla standardowa klasa
"class string", nastapilo ogromne uproszczenie i takich konstrukcji stosowac juz nie trzeba.

------------------------------------------------------
int main()
------------------------------------------------------
Dodana funkcja wyczysc ekran
  void wyczysc_ekran()
Deklaracja jest na samej gorze programu, definicja na samym dole
************************************************************/


