//***************************************************
// Program z paragrafu  4.6 (str 68)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream>
using namespace std ;

int   main()
{
     int a ;
     cout << "Musisz odpowiedziec TAK lub NIE \n"
          << "jesli TAK, to napisz 1 \n"
          << "jesli NIE to napisz 0 \n"
          << " Rozumiesz ? Odpowiedz : "  ;

          cin >> a ;                         //

          cout << "Odpowiedziales : "
               << (  a? "TAK" : "NIE" )      //
               << " prawda ? " ;

 }


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()


************************************************************/
