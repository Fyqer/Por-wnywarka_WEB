//***************************************************
// Program z paragrafu   17.3 (str 407)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

#include <cstring>

class numer ;                                             //
///////////////////////////////////////////////////////
class zespol {
     float rzeczyw ;                                   //
     float urojon ;
public :
     // dwa konstruktory konwertujace
     zespol(float r = 0, float i = 0):rzeczyw(r),urojon(i)
     { }
     zespol(numer ob);                                   //

     operator float() { return rzeczyw ; }             //
     operator numer() ;
     void pokaz()
     {
          cout << "\tLiczba zespolona: (" << rzeczyw
               << ", " << urojon << ") \n" ;
     }
     friend zespol dodaj(zespol a, zespol b) ;
} ;
///////////////////////////////////////////////////////
class numer {
     float n ;
     char opis[80];                                     //
     friend zespol::zespol(numer);
     friend void plakietka(numer);
public:
     numer(float k, char *t = "opis domniemany")
                                             : n(k)     //
     {
          strcpy(opis, t);
     }
     operator float() { return n ; }                    //
};
///////////////////////////////////////////////////////
zespol::zespol(numer ob) : rzeczyw(ob.n), urojon(0)
{ /* puste cialo, bo wszystko zrobione w liscie inicjalizacyjnej
*/ }
/******************************************************/
zespol::operator numer()
{
        // pomagamy sobie wywolujac konstruktor (ale juz nie konwertujacy,
        // bo wywolywany z 2 argumentami).

     return numer(rzeczyw, "powstal z zespolonej") ;
}
/******************************************************/
// deklaracje funkcji globalnych
void pole_kwadratu(float bok);
void plakietka(numer nnn);
zespol dodaj(zespol a, zespol b);
/*******************************************************/
main()
{
     // definicje trzech obiekt�w
     float     x = 3.21 ;
     numer     nr(44, "a imie jego") ;
     zespol     z(6, -2);

     // wywolania funkcji pole_kwadratu(float);

     pole_kwadratu(x);               // niepotrzebna zadna konwersja
     // ponizsze wywolania nie sa dopasowane, ale mimo to mozliwe, bo

     // kompilator samoczynnie zastosuje nasze konwersje
     pole_kwadratu(nr);        // operator konwersji numer-->float

     pole_kwadratu(z);        // operator konwersji zespol-->float


     // ------------------------------------------------
     zespol      z2(4,5) ,               // def 2 roboczych obiekt�w
               wynik ;

     // wywolania funkcji dodaj(zespol, zespol)


     wynik = dodaj(z, z2) ;          // niepotrzebna zadna konwersja
     wynik.pokaz();

     // ponizsze wywolania nie sa dopasowane, ale mimo to mozliwe,bo
     // kompilator samoczynnie zastosuje nasze konwersje

     wynik = dodaj(z, x);// konstr. konwertujacy float-->zespol

     wynik.pokaz();

     wynik = dodaj(z, nr);// konstr. konwertujacy numer-->zespol

     wynik.pokaz();

     //--------------------------------------------------------------


     // wywolania funkcji plakietka(numer) ;

     plakietka(nr);

     // ponizsze wywolania nie sa dopasowane, ale mimo to mozliwe, bo
     // kompilator samoczynnie zastosuje nasze konwersje
     plakietka(x);          // konstr. konwertujacy float --> numer
     plakietka(z);          // operator konwersji zespol --> numer

}
/*****************************************************/
zespol dodaj(zespol a, zespol b)
{
     zespol chwilowy(a.rzeczyw + b.rzeczyw,
                      a.urojon  + b.urojon);
     return chwilowy ;
}
/*****************************************************/
void plakietka(numer nnn)
{
     cout << "*****************************" << endl ;
     cout << "***                       ***\r"
          << "*** " << nnn.opis << endl ;
     cout << "***                       ***\r"
          << "***             " << nnn.n << endl ;
     cout << "*****************************" << endl ;
}
/*****************************************************/
void pole_kwadratu(float bok)
{
     cout << "Pole kwadratu o boku " << bok
          << " wynosi " << (bok * bok) << endl ;
}
/******************************************************/


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <cstring>
------------------------------------------------------


-----------------------------------------------------
    if(nn) strcpy(nazwa, nn);                           // <----- dodane sprawdzenie if
     if(pp) strcpy(przesiadki, pp) ;                    // <----- dodane sprawdzenie if


bo gdybyw wskaznik nn lub pp mial wartosc zero, to funkcja strcpy wywolaby  blad pamieci
-----------------------------------------------------
int main()
------------------------------------------------------



************************************************************/

