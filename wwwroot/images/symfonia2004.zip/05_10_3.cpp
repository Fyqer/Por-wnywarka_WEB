//***************************************************
// Program z paragrafu  5.10.3 (str 99)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

/* ----------- deklaracje funkcji ----------*/
void czerwona(void) ;                                   //
void biala(void) ;
/*----------------------------------------------------*/
int main()
{
     czerwona();                                        //
     czerwona();
     biala();
     czerwona();
     biala();

}
/******************************************************/
void czerwona(void)
{
static int ktory_raz ;                                   //
     ktory_raz ++ ;
     cout      << "Funkcja czerwona wywolana "<< ktory_raz
               << " raz\n" ;
}
/******************************************************/
void biala(void)
{
static int ktory_raz = 100 ;                              //
     ktory_raz = ktory_raz + 1 ;                         //
     cout      << "Funkcja biala wywolana "<< ktory_raz
               << " raz\n" ;                               //
}
/******************************************************/



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()



************************************************************/
