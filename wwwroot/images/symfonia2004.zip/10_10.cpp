//***************************************************
// Program z paragrafu   10.10 (str 278)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;


int balkon = 77 ;                    // nazwa globalna          //
void spiew() ;                    // deklaracja jakiejs funkcji (globalnej)

//////////////////// definicja klasy ////////////////////
class opera {
public:
     int     n ;
     float balkon ;                              // skladnik klasy
     // ...

     void      funkcja() ;
     void     spiew()                                        //
     {
          cout << "funkcja spiew (z opery) : tra-la-la !\n" ;
     }
} ;
////////////////   koniec definicji klasy ///////////////
void opera::funkcja()                                   //
{
               // jeszcze sie nic nie dzieje
     cout << "balkon (skladnik klasy) = "
          << balkon << endl ;                         //
     cout << "balkon (zmienna globalna) = "
          << ::balkon << endl ;


               // definicja zmiennej lokalnej (lokalnej dla tej funkcji)

     char balkon = 'M' ;                              //

     cout << "\nPo definicji zmiennej lokalnej ---\n" ;
     cout << "balkon (zmienna lokalna) = " << balkon << endl;

     cout << "balkon (skladnik klasy) = " << opera::balkon
          << endl ;
     cout << "balkon (zmienna globalna) = "
          << ::balkon << endl ;

     // ------wywolanie funkcji
     spiew();                                             //

     int spiew ;                                      //

     spiew = 7 ;                                     //
     // spiew() ;          // <- blad w trakcie kompilacji

                         // bo nazwa funkcji - juz zaslonieta

     cout<< "Po zaslonieciu da sie wywolac "
               "funkcje spiew tylko tak\n" ;
     opera::spiew();                     // tak mozna
}
/******************************************************/
int main()
{
opera Lohengrin ;

     Lohengrin.balkon = 6 ;           //
     Lohengrin.funkcja();          //
     spiew();                          //

}
/******************************************************/
void spiew()
{
     cout << "zwykla funkcja spiew (nie majaca nic"
               " wspolnego z klasa)\n" ;
}







/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------
int main()


-------------------------------------------------------

************************************************************/
