//***************************************************
// Program z paragrafu   10.15 (str 296)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;


////////////////////////////////////////////////////////
class pion {
private :
     int pozycja ;
     static int pensja ;                         //

public:
     static int ile_pionkow ;                    //

     // funkcje skladowe
     //------
     pion() {                         // konstruktor
          pozycja = 0 ;
          ile_pionkow ++ ;                        //
     }
     //------
     int przesun(int ile)                         //
     {
          return (pozycja += ile) ;
     }
     //------
     int ile_zarabia() {                          //
          return pensja - 800;      // oszust !
     }
} ;
////////////////////////////////////////////////////////
int pion::pensja = 3000 ;                         //
int pion::ile_pionkow ;
/*******************************************************/
int main()
{
     cout << "Poczatek programu, teraz jest pionkow = "
          << pion::ile_pionkow ;

     pion czerwony, zielony ;          //definicje pionkow

     cout << "\nPo definicji pionkow \n" ;

     // odczytywanie informacji zapisanych wdanej statycznej (public)

     cout << "Klasa mowi ze pionkow jest  "
          << pion::ile_pionkow << endl ;
     cout << "czerwony, ze "
          << czerwony.ile_pionkow << endl ;              //
     cout << "zielony, ze " << zielony.ile_pionkow << endl;

     pion bialy ;                         //definicja pionka

     cout << "Po definicji jeszcze jednego jest ich : "
          << zielony.ile_pionkow << endl ;             //

     // pionki ida do przodu, ale to nas nie interesuje
     zielony.przesun(2);
     czerwony.przesun(6);
     bialy.przesun(3);

     // interesuje nas ile zarabia pionek (dana
     // statyczna prywatna)
     /*    cout << "pionek zarabia "
                << pion::pensja;   */     // blad !

     // jedyna szansa to zapytac pionka funkcja skladowa
                                                       //
     cout << "Czerwony, ile zarabiacie ? "
          << czerwony.ile_zarabia() ;
     cout << "\nBialy, ile zarabiacie ? "
          << bialy.ile_zarabia() ;

}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------
int main()

------------------------------------------------------

************************************************************/
