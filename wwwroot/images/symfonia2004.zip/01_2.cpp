//***************************************************
// Program z paragrafu  1.2 (str 10)
//***************************************************
// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



/*  ----------------------------------------------------
Program na przeliczanie wysokosci podanej
w stopach na wysokosc w metrach.
Cwiczymy tu operacje wczytywania z klawiatury
i wypisywania na ekranie
------------------------------------------------------*/
#include <iostream>
using namespace std ;

int main()
{
int           stopy ;              // to do przechowywania liczby stop
float      metry ;                 // do wpisania wyniku
float      przelicznik = 0.3 ;     // przelicznik: stopy na metry

     cout << "Podaj wysokosc w stopach : " ;
     cin >> stopy ;                    	// przyjecie danej z klawiatury

     metry = stopy * przelicznik;      	// wlasciwe przeliczenie

     cout << "\n" ;			// to samo co  cout << endl ;

     // -----wypisanie wynikow
     cout << stopy << " stop - to jest : "
          << metry << " metrow\n" ;


}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()



************************************************************/
