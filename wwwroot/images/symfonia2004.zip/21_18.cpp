//***************************************************
// Program z paragrafu   21.18 (str 666)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;
#include <fstream>
#include <cstdlib>           // dla exit()
////////////////////////////////////////////////////////
class duza_tablica {                                      //
      const char *nazwa_pliku ;       // nazwa pliku dyskowego
      fstream plik ;

      const int rozmiar ;

      int * linijka ;          // linijka w zapasie pamieci
      long dlug_linijki ;
      int nr_obecnego ;          // nr wiersza nad ktorym pracujemy
public:
       duza_tablica(const char *nazwa_pliku, int wym, int wypelniacz = 0);
       ~duza_tablica() ;

       int * operator[](int wiersz) ;
private:
       void error();
} ;
/*******************************************************/
duza_tablica::duza_tablica(const char *nazwa, int wym,
          int wypelniacz) : rozmiar(wym)              //
{
         plik.open(nazwa,  ios_base::trunc   // <-- dodane trunc
                         | ios_base::in | ios_base::out
                         | ios_base::binary) ;

     nazwa_pliku = nazwa ;                               //

     if(!plik){
          cout << "Blad otwarcia pliku " << nazwa << endl;
          error() ;
     }

     linijka = new int[rozmiar] ;                  //
     dlug_linijki = rozmiar * sizeof(int);

     // ------------------------- wstepne wypelnienie
     for (int i = 0 ; i < rozmiar ; i++)
                    linijka[i] = wypelniacz ;

     // -----------------------zapis tego do pliku
     for (int k = 0 ;  (k < rozmiar) && plik.good() ; k++)
          plik.write( (char*)linijka, dlug_linijki ) ;
                                                       //

     if(!plik){
          cout << "Blad podczas wypelniania tablicy"
               << endl ;
          error();
     }
     nr_obecnego = 0 ;
}
/*******************************************************/
duza_tablica::~duza_tablica()      //
{
     // skoro koniec to musimy odeslac na dysk wiersz
     // ktory jest jeszcze w tablicy linijka

     if(! plik.seekp(nr_obecnego * dlug_linijki)) {
          cout << "Blad pozycjonowania "
                    "wskaznika pisania\n";
          error();
     }
     // zapisanie tam ---------
     if(!plik.write( (char*)linijka , dlug_linijki) ){
          cout << "Blad przy odsylaniu\n" ;
          error();
     }

     plik.close();        // zamkniecie pliku
     delete linijka ;     // zwolnienie rezerwacji
}
/*******************************************************/
// przeladowanie operatora []
/*******************************************************/
int * duza_tablica::operator[](int nr_wiersza_chcianego)
{                                                      //

     //=============================
     //      moze dany fragment tablicy jest pod reka ?
     //=============================
     if(nr_wiersza_chcianego == nr_obecnego){
           return linijka ;    // nic nie trzeba robic !
     }

     //=============================
     // jesli nie, to najpierw odsylamy obecny wiersz=

     // ============================
     // obliczenie gdzie go poslac
     if(! plik.seekp(nr_obecnego * dlug_linijki)) {
          cout << "Blad pozycjonowania wskaznika pisania\n";
          error();
     }
     // zapisanie tam -------------------------
     if(!plik.write( (char*)linijka , dlug_linijki) ){
          cout << "Blad przy odsylaniu\n" ;
          error();
     }
     // ===================================
     // sprowadzamy potrzebny wiersz    ===
     // ===================================
     // obliczenie gdzie  on w pliku jest

     if(! plik.seekg(nr_wiersza_chcianego * dlug_linijki))
     {
          cout << "Blad pozycjonowania wskaznika czytania"
               << nr_wiersza_chcianego * dlug_linijki
               << endl ;
          error();
     }

     // przeczytanie tego fragmentu ------------------------
     if(!plik.read( (char*) linijka, dlug_linijki) ){
          cout << "Blad czytania wiersza "
               << nr_wiersza_chcianego << endl ;
          error();
     }

     // uaktualnienie notatek
     nr_obecnego = nr_wiersza_chcianego ;

     // zwracamy wskaznik do tablicy roboczej
     return linijka ;
}
/*******************************************************/
void duza_tablica::error()
{
     if(plik.eof())  cout << "Koniec pliku " ;
     if(plik.fail())
          cout << " -FAIL strumienia do pliku : "
                << nazwa_pliku << endl ;
     exit(1);
}
/*******************************************************/
int main()                                               //
{
int i, k;
const int wymiar = 50 ;

duza_tablica t("macierz.tmp", wymiar) ;                //


     // wpisanie jakichs danych do tablicy t
     for(i = 0 ; i < wymiar ; i++)
          for(k = 0 ; k < wymiar ; k++)
                    t[i][k] = i * 100 + k ;                 //

     cout << "Element t [24][7] ma wartosc = "
          << t [24][7] << endl ;                       //

     // -------------------------------------------
     cout << "Przykladowo robimy transpozycje " <<endl ;

     duza_tablica m("macierz1.tmp", wymiar) ;          //
     for(i = 0 ; i < wymiar ; i++)
          for(k = 0 ; k < wymiar ; k++)
               m[i][k] = t[k][i] ;                     //

     cout << "transpozycja skonczona, oto rezultat\n"
               "Przykladowo elementy t[7][31] = " << t[7][31]
          << ", \tt[31][7] = " << t[31][7] << endl ;

     cout << "  Natomiast elementy m[7][31] = " << m[7][31]
          << ", \tm[31][7] = " << m[31][7] << endl ;
}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <fstream>
#include <cstdlib>           // dla exit()
------------------------------------------------------
int main()
------------------------------------------------------
Zmienil sie zakres waznosci licznika petli.
Teraz w tej drugiej petli - obiekt "i" jest juz nieznany.
Wystarczylo by wiec umiescic tam
     for (int i = 0 ; ... itd

Niestety VC++ nie zgadza sie na to proste rozwiazanie
(wbrew standardowi).
Dla swietego spokoju zmienilem nazwe tej drugiej zmiennej
"i" na "k"


for (int k = 0 ;  (k < rozmiar) && plik  ; k++)

Dodatkowo tu dalem jasne speawdzenie czy pisanie do pliku
jest nadal mozliwe (zauwaz funkcje good() )
     
for (int k = 0 ;  (k < rozmiar) && plik.good() ; k++)
	 
	   
-------------------------------------------------------
 duza_tablica(const char *nazwa_pliku, int wym, int wypelniacz = 0);

Zarowno w deklaracji jak i definicji tego konstruktora dodany
jest przydomek "const".


------------------------------------------------------
plik.open(nazwa, ios_base::trunc | ios_base::in
                | ios_base::out | ios_base::binary) ;

Dodany tryb ios_base::trunc, ktory sprawia ze jesli plik nieistnieje
- zostaje stworzony, a jesli istnieje - wyzerowany.


W zasadzie byloby ladniej gdyby w destrukotrze usuwac ten plik
z dysku. Nie zrobilem tego jednak bo usuwanie pliku nie jest
objete standardem - to znaczy inna komenda robi sie np. w UNIXie
a inna komenda w Widnows.


-----------------------------------------------------------
Wszystkie wystapienia kwalifikatora ios:: zostaly
zamienione na ios_base::

************************************************************/


