//***************************************************
// Program z paragrafu   8.3 (str 153)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

//****************************************************
int main()
{
int zmienna = 8 , drugi = 4 ;                         //
int *wskaznik ;                                        //

     wskaznik = &zmienna ;                              //

     // prosty wypis na ekran ;
     cout << "zmienna = " << zmienna
          << "\n a odczytana przez wskaznik = "
          << *wskaznik << endl ;

     zmienna = 10 ;                                    //
     cout << "zmienna = "<< zmienna
          << "\n a odczytana przez wskaznik = "
          << *wskaznik << endl ;

     *wskaznik = 200 ;                                   //
     cout << "zmienna = " << zmienna
          << "\n a odczytana przez wskaznik = "
          << *wskaznik << endl ;

     wskaznik = &drugi ;                              //
     cout << "zmienna = "<< zmienna
          << "\n a odczytana przez wskaznik = "
          << *wskaznik << endl ;

}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------

int main()


************************************************************/
