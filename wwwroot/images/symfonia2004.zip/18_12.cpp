//***************************************************
// Program z paragrafu   18.12 (str 466)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

/////////////////////////////////////////////////////////
class tab_calkow {
     int a[100] ;
public :
      // deklaracja funkcji operatorowej
     int & operator[](unsigned int ktory)          // tutaj cala
     {                                                  // tajemnica
          return  a[ktory] ;
     }
} ;
////////////////////////////////////////////////////////
int main()
{
tab_calkow t ;

     for(int i = 0 ; i < 100 ; i++)
          t[i] = 100 + i ;          // zaladowanie tablicy

     // pracujemy tak jak na zwyklej tablicy !
     t[1] = t[2] + 50 + t[3] ;

     cout << "Mamy kolejno "
          << t[0] << ", " << t[1] << ", "
          << t[2] << ", " << t[3] << " itd..." ;
}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;


-----------------------------------------------------
int main()
------------------------------------------------------



************************************************************/


