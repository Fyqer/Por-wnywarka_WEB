//***************************************************
// Program z paragrafu   13.1 (str 328)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)

// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
// ALE wymaga ujecia jednej linii w komentarz, bo VC++ nie zachowuje
// sie wedlug standardu. Ta krytczna liniia ma komentarz 
// takiej tresci:  "vc++ tu NIESLUSZNIE protestuje"


 
#include <iostream>
using namespace std ;

int xyz = 10 ;                     // zmienna globalna
void zwykla() ;
/*******************************************************/
int main()
{
     zwykla() ;
     // lokalik BBB ;



}
/*******************************************************/
void zwykla()
{
int xyz = 15 ;                                          //
int lokal_autom ;                                       //
static float lokal_stat = 77 ;                          //

     class lokalik
     {
     public :
          // static int sss ;        // blad - klasa nie moze
                                   // miec skladnikow statycznych
          void lok_funskl()
          {
            cout << "to jest inline"
                 << ",   ::xyz= " << ::xyz << endl             //
                 // << lokal_autom    // blad !      //
                 << "lokal_stat= "    << lokal_stat        // o.k. !  // vc++ tu NIESLUSZNIE protestuje
                 << endl ;
          }
     } ;

     cout << "jestem w zwyklej funkcji \n"  ;
     lokalik A ;                                      //
     A.lok_funskl() ;                              //


}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;


------------------------------------------------------

   void lok_funskl()
          {
               cout << "to jest inline"
                    << ",   ::xyz= " << ::xyz << endl             // <----n tutaj dodane "::"
                    // << lokal_autom    // blad !      //
                     << "lokal_stat= "    << lokal_stat        // o.k. !          //
                    << endl ;
          }

Uwaga, w mysl nowego standardu nie mozemy sie oczywiscie
probowac odniesc do obiektu lokalnego xyz
(Wiadomo). Kompilator zaprotestuje.
My jednak mielismy ten globalny - o identycznej nazwie.
Skoro tak, to nalezy to slowo "globalny" wypowiedziec
glosno - czyli nazwe xyz poprzedzic dwoma dwukropkami.

Tak jest moim zdaniem lepiej, bo przy takiej zasadzie
programista daje kompilatorowi do zrozumienia, ze wie iz to nie
do lokalnego xyz sie odnosi.


------------------------------------------------------
int main()
------------------------------------------------------



************************************************************/
