//***************************************************
// Program z paragrafu  7.3 (str 134)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream>
using namespace std ;

void potrojenie(int ile, long tablica[]);          //
/******************************************************/
int main()
{
const int rozmiar = 8192 ;                         //
long widmo[rozmiar] ;                              //

     // ----------nadanie wartosci poczatkowej
     for(int i = 0 ; i < rozmiar ; i ++)
     {
          widmo[i] = i ;                              //
          if(i < 6)          // pokazanie pierwszych szesciu
               cout << "widmo[" << i << "]= " << widmo[i]
               << endl ;
     }
     // ----------uwaga, wywolujemy funkcje !
     potrojenie(rozmiar, widmo) ;                    //
     cout << "Po wywolaniu funkcji \n" ;
     for(int k = 0 ; k < 4 ; k ++)
     {                                              //
          cout << "widmo[" << k << "]= " << widmo[k] << endl ;
     }

}
/******************************************************/
void potrojenie (int ile, long t[])               //
{
     for(int i = 0 ; i < ile ; i++)
     {
          t[i] *= 3 ;                               //
     }
}
/******************************************************/



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()
------------------------------------------------------
     for(int k = 0 ; k < 4 ; k ++)
     {                                              //
          cout << "widmo[" << k << "]= " << widmo[k] << endl ;
     }

W tej petli zmienilem nazwe zmiennej z "i" na "k"

To dlatego ze w mysl nowego standardu zmienna i
zdefiniowana na uzytek wczesniejszej petli -
w tej drugiej petli powinna juz byc nieznana.

Wlasciwie wiec wystarczylo dopisac tam to slowko "int"
	for(int i ...
po raz drugi definiujac obiekt o takiej nazwie (poprzedni juz nie istnieje).
Jednak poniewaz rozne kompilatory dopuszczaja jeszcze tamta
(przestarzala) zasade, dlatego by uniknac zamieszania
dalem inna nazwe.

------------------------------------------------------
Zmienilem tekst wypisu na ekran. Teraz jest tam
widmo[0]= ...
co mi sie wydaje jasniejsze

------------------------------------------------------



************************************************************/
