//***************************************************
// Program z paragrafu   21.23.1 (str 683)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

#include <iomanip>

// PRZESTARZALY
#include <strstream>   // <--- bo uzywamy ostrstream

// NOWY SPOSOB
#include <sstream>   // <-- bo  uzywamy ostringstream

/*******************************************************/
int main()
{

  cout << "############## Stary sposob ##############" << endl;

ostrstream skryba ;                                      //

     skryba << "To jest poczatek " ;

     for(int i = 0 ; i < 100 ; i++)
     {
          skryba << "\nOperacja nr " << i  ;          //
          if(!skryba)
          {
               cout << "Blad strumienia skryba " ;
               return (1);            // koniec programu
          }
     }
     skryba << ends ;                 // dopisujemy znak NULL

     char *wsk ;
     wsk = skryba.str() ;                                  //

     cout << "Odebralem juz adres do tablicy "<< endl
          << "oto jej tresc : \n"
          << wsk
          << "\nto juz koniec \n" ;

     delete wsk ;                                        //


  cout << "############## NOWY sposob ##############" << endl;

  ostringstream skryba2 ;                                      //

     skryba2 << "To jest poczatek " ;

     for(int ii = 0 ; ii < 100 ; ii++)
     {
          skryba2 << "\nOperacja nr " << ii  ;          //
          if(!skryba2)
          {
               cout << "Blad strumienia skryba " ;
               return (1);            // koniec programu
          }
     }

     // PONIZSZA LINIJKA JEST NIEPOTRZEBNA
     // skryba2 << ends ;                 // dopisujemy znak NULL


     cout << "Odebralem juz adres do tablicy "<< endl
          << "oto jej tresc : \n"
          << skryba2.str()
          << endl ;

                                    //

     skryba2 << " Nowy dopisek " << endl;

     cout << "Po dalszych operacjach \n"
          << skryba2.str()
          << "\nto juz koniec \n" ;


}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <iomanip>
#include <strstream>   // <--- bo uzywamy ostrstream


------------------------------------------------------
Operacje pokazywane tutaj w programie sa tak czeste, ze
wprowadzone sa ulepszenia. Krotko mowiac mozna to zrobic
teraz jeszcze prosciej - z pomoca nieco innej klasy

Aby z tego skorzystac potrzebna jest dyrektywa

#include <sstream>   // <-- bo  uzywamy ostringstream
------------------------------------------------------
int main()
------------------------------------------------------



Oprocz starego sposobu, do ktorego nowy standard juz
zniecheca - (choc ciagle akceptuje) pokazuje tu
leszy sposob - z uzyciem klasy o nazwie ostringstream


  cout << "############## NOWY sposob ##############" << endl;

  ostringstream skryba2 ;            // <NOWA, LEPSZA KLASA OBIEKTU                          //

     skryba2 << "To jest poczatek " ;

     for(int ii = 0 ; ii < 100 ; ii++)
     {
          skryba2 << "\nOperacja nr " << ii  ;          //
          if(!skryba2)
          {
               cout << "Blad strumienia skryba " ;
               return (1);            // koniec programu
          }
     }

     // PONIZSZA LINIJKA JEST NIEPOTRZEBNA
     // STRING ZAWSZE BEDZIE DOBRZE ZAKONCZONY
     // skryba2 << ends ;                 // dopisujemy znak NULL


     cout << "Odebralem juz adres do tablicy "<< endl
          << "oto jej tresc : \n"
          << skryba2.str()    // <---- PIEWSZE WYWOLANIE str()
          << endl ;

                                    //

     skryba2 << " Nowy dopisek " << endl;  // <-- PRACUJEMY DALEJ

     cout << "Po dalszych operacjach \n"
          << skryba2.str()     // <--- DRUGIE WYOWLANIE str()
          << "\nto juz koniec \n" ;


W wypadku tej nowej, lepszej klasy ostringstream
nie ma opisywanego w tekscie "przejscia na emerture".

Strumien, mimo wyolania funkcji str() nadal nadaje
sie do dalszej pracy!

Ta funkcja str() po prostu zwraca kopie stringu, a potem
na oryginalnym stringu dalej mozna i tak pracowac.
Co zreszta widac w naszym programie - funkcje te
wywolujemy przeciez dwukrotnie.


Wniosek: mechanizm automatycznej rezerwacji miejsca
nie wymaga od nas pamietania o zwolnieniu obszaru
pamieci
-------------------------------------------------------

************************************************************/


