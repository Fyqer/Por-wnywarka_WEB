//***************************************************
// Program z paragrafu   21.10.1 (str 615)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

/********************************************************/
int main()

{
float x = 1175 ;
ios_base::fmtflags   stare_flagi ;

     cout << x << endl;

     cout <<"Zapamietanie flag formatowania\n" ;
     stare_flagi = cout.flags();                         //

     cout.setf(ios::showpoint) ;
     cout << x << endl ;

     cout.setf(ios::scientific, ios::floatfield);
     cout << x << endl ;

     cout.setf(ios::uppercase);
     cout << x << endl ;

     cout.unsetf(ios::showpoint) ;
     cout << x << endl ;

     cout <<"Powrot do starego sposobu formatowania\n" ;
     cout.flags(stare_flagi);                          //
     cout << x << endl ;

}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------
------------------------------------------------------
int main()
------------------------------------------------------
ios_base::fmtflags   stare_flagi ;

W nowym standardzie stan flag zapisywany jest
w obiekcie ktorego wyglad zalezny jest od konkretnej
implementacji. Aby programista nie musial sie tym
przejmowac, ten tajemniczy typ opisany jest
w klasie ios_base za pomoca instrukcji typedef i ma on nazwe
 fmtflags
 (a lacznie z kwalifikatorem zakresu ios_base::fmtflags)

Latwo to zapamietac, bo to jakby skrot od slow
ForMaT FLAGS  (flagi formatowania)

************************************************************/


