//***************************************************
// Program z paragrafu  3.4.1 (str 36)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream>
using namespace std ;
int main()
{
int i      ;          // definicja obiektu
int k, n, m, j ;

     i = 5 ;
     k = i + 010 ;               // czyli 5 + 8

     cout << "k= " << k << endl ;

     m = 100 ;
     n = 0x100 ;
     j = 0100 ;

     cout << "m+n+j= " << (m+n+j) << endl ;

     cout << "Wypisujemy :  "     << 0x22 << " "
          << 022  << " " << 22   << endl ;

 }


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()



************************************************************/
