//***************************************************
// Program z paragrafu  3.4.2 (str 36)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;
int main()
{
float pole, promien ;

     promien = 1.7 ;
     pole = promien * promien * 3.14 ;
     cout << "\nPola kola o promieniu "
          << promien << " wynosi " << pole ;

     promien = 4.1e2 ;
     pole = promien * promien * 3.14 ;
     cout << "\nPola kola o promieniu "
          << promien << " wynosi " << pole ;

 }


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()


************************************************************/
