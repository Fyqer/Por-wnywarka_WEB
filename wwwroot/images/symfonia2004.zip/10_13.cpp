//***************************************************
// Program z paragrafu   10.13 (str 288)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;

#include <cstring>               // bo uzyjemy: strcpy()

///////////////////////////////////////////////////////
class numer {
     int     liczba ;
     char nazwa[40] ;
public:
     // --------funkcje skladowe
     // konstruktor -tylko deklaracja
     numer(int l, const char *opis) ;                          //

     // dalsze funkcje skladowe
     void     schowaj(int l)
     {
          liczba = l ;
          melduj() ;                                     //
     }
     // -----
     int     zwracaj()      { return liczba ; }
     // ----
     void melduj()                                       //
     {
          cout << nazwa << liczba << endl ;
     }
} ;
////////  koniec definicji klasy ///////////////////////
numer::numer(int l, const char *opis)                       //
{
     liczba = l ;

      if(opis)
        strcpy(nazwa, opis);
     else
        nazwa[0] = 0 ; // pusty string
}
/******************************************************/
int main()
{
numer  samolot(1200, "Biezaca wysokosc ") ;             //
numer  atmosfera(920, "Cisnienie atmosferyczne "),     //

       kurs(63, "Kierunek lotu ");

       // wstepny raport

       samolot.melduj() ;
       kurs.melduj();                                   //
       atmosfera.melduj();

       cout << "\nKorekta lotu -----\n" ;
       samolot.schowaj(1201);                         //

       // zmiana kursu o 3 stopnie
       kurs.schowaj( kurs.zwracaj() + 3) ;               //

       //cisnienie spada
       atmosfera.schowaj(919) ;

}









/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <cstring>

------------------------------------------------------

     numer(int l, const char *opis) ;                          //

W tej deklaracji a takze potem w definicji tej funkcji dodane zostaly
przydomki "const", za kazdym razem z tego samego powodu:
Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*



------------------------------------------------------
int main()


-------------------------------------------------------
-------------------------------------------------------
W definicji konstruktora numer dodane zostalo sprawdzenie
czy wskaznik do stringu nie pokazuje czasem na adres 0 (NULL).
Gdyby tak bylo, to funkcja strcpy spowodowalaby blad pamieci.
Zatem najpierw to sprawdzamy, a jesli ta, to do tablicy nazwa
wpisujemy 0 do zerowego elementu, co odpowiada pustemu stringowi

    if(opis)
        strcpy(nazwa, opis);
     else
        nazwa[0] = 0 ; // pusty string

************************************************************/
