//***************************************************
// Program z paragrafu   8.10.3   (str 190)
//***************************************************

// Sprawdzony na Linuksie,   kompilator: GNU gcc version 3.3.3 (SuSE Linux)

// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0 ALE:
// Niestety VC++ moze sie tu zachowac niestandardowo... 


#include <iostream>
using namespace std ;

#include <cstdlib>                         //
#include <new>                             //


/******************************************************/
void funkcja_alarmowa() ;                    //
long k ;                                     //
/*******************************************************/
int main()
{
     set_new_handler(funkcja_alarmowa);               //

     for(k = 0 ;  ; k++ )
     {
          new int ;                    // tworzenie obiektu
     }

}
/******************************************************/
void funkcja_alarmowa()
{
     cout << "\n zabraklo pamieci przy k = "
          << k << " !\n" ;
     exit(1) ;                                        //
}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <cstdlib>                         //
#include <new>                             //

------------------------------------------------------

int main()

------------------------------------------------------



************************************************************/
