//***************************************************
// Program z paragrafu   21.26 (str 679)
//***************************************************
#include <iostream.h>
#include <fstream.h>          // <--- nie zapomnij o tym !
#define DRUKARKA ofstream("prn", ios::out)
/******************************************************/
main()
{
float liczba = 3.14 ;
     ofstream("prn", ios::out) << "Mocium Panie!" << endl ;

     ofstream("prn", ios::out)      << "Jakis tekst " << liczba
                               << " znowu tekst " << 8+43.2
                               << " po liczbie " << endl ;
     // Sposob dla leniuchow ----------------------------

     DRUKARKA      << "Mocium Panie! " << endl ;

     DRUKARKA      << "Jakis tekst " << liczba
               << " znowu tekst " << 8+43.2
               << " po liczbie " << endl ;
}
/******************************************************/

