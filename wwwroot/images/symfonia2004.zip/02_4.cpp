//***************************************************
// Program z paragrafu  2.4 (str 19)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0




#include <iostream>
using namespace std ;
int main()
{
char litera ;
     do {
          cout << "Napisz jakas litere  :  " ;
          cin  >> litera ;
          cout << "\n Napisales : " << litera << " \n" ;
     }while(litera != 'K');      //

     cout << "\n Skoro Napisales K  to  konczymy  !" ;

 }


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()



************************************************************/
