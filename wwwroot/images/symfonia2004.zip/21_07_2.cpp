//***************************************************
// Program z paragrafu   21.7.2 (str 594)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

/////////////////////////////////////////////////////////
class samochod {
public:
     int rok_produkcji ;
     virtual void rzecznik (ostream & strum);
} ;
/////////////////////////////////////////////////////////
class mercedes : public samochod {
public:
     const char *model ;
     void rzecznik(ostream & strum) ;
} ;
/*******************************************************/
// realizacja operatora << dla klasy podstawowej
/*******************************************************/
ostream & operator<<(ostream &strum , samochod &x)     //

{
     x.rzecznik(strum) ;                              //
     return strum ;
}
/*******************************************************/
//     realizacje funkcji wirtualnych
/*******************************************************/
void samochod::rzecznik(ostream & strum)
{
     strum << rok_produkcji  ;
}
/*******************************************************/
void mercedes::rzecznik(ostream & strum)
{
     samochod::rzecznik(strum);
     strum << " " << model ;
}
/*******************************************************/
int main()
{

samochod a, b ;

          a.rok_produkcji =  1990 ;
          b.rok_produkcji =  1992 ;

mercedes m ;

          m.rok_produkcji =  1991;
          m.model = "sportowy" ;

     cout << a  << endl ;
     cout << b  << endl ;
     cout << m  << endl ;
}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------
class mercedes : public samochod {
public:
     const char *model ;   <-- dodane const

Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*

Optymistyczna uwaga: od czasu, gdy do biblioteki standardowej weszla standardowa klasa
"class string", nastapilo ogromne uproszczenie i takich konstrukcji stosowac juz nie trzeba.

------------------------------------------------------
int main()
------------------------------------------------------
int i ;  <-- w funkcji main, bylo przez zapomnienie, skasowalem


************************************************************/


