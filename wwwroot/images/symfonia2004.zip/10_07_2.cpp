//***************************************************
// Program z paragrafu   10.7.2 (str 273)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 

#include <iostream>
using namespace std ;

#include <cstring>                                   //


//////////////////   definicja klasy  /////////////////
class osoba {
     char nazwisko[80] ;                               //
     int wiek ;
public :                                               //
     void zapamietaj(const char * napis, int lata) ;         //
     //------------
     void wypisz()                                  //

     {
          cout << "\t" << nazwisko << " , lat : "
               << wiek << endl ;
     }
} ;
/////////////////// koniec definicji klasy //////////////
void osoba::zapamietaj(const char * napis, int lata)          //

{
     if(napis)
             strcpy(nazwisko, napis) ;
     else
             nazwisko[0] = 0 ; // pusty string

     wiek = lata ;
}
/******************************************************/
int main()
{


osoba student1, student2, profesor, pilot ;

     cout << "Dla informacji podaje, ze jeden obiekt "
               "klasy osoba\n ma rozmiar : "
          << sizeof(osoba)                             //
          << " bajty. To samo inaczej : "
          << sizeof(student1)   << endl ;

     profesor.zapamietaj("Albert Einstein", 55);    //
     student1.zapamietaj("Ruediger Schubart", 26);
     student2.zapamietaj("Claudia Bach", 25);
     pilot.zapamietaj("Neil Armstrong", 37);

     cout << "Po wpisaniu informacji do obiektow. "
               "Sprawdzamy : \n";
     cout << "dane z obiektu profesor\n";
     profesor.wypisz();

     cout << "dane z obiektu student1\n";
     student1.wypisz();

     cout << "dane z obiektu student2\n";
     student2.wypisz();                                 //

     cout << "dane z obiektu pilot\n";
     pilot.wypisz();

     cout << "Podaj swoje nazwisko (tylko nazwisko) : " ;
     char magazynek[80] ;
     cin >> magazynek ;                                   //

     cout << "Podaj swoj wiek : " ;
     int ile ;
     cin >> ile ;

     pilot.zapamietaj(magazynek , ile);             //

     cout << "Oto dane ktore teraz sa zapamietane "
               "w obiektach profesor i pilot \n" ;

     profesor.wypisz() ;
     pilot.wypisz();                                //

}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

#include <cstring>                                   //



------------------------------------------------------
void osoba::zapamietaj(const char * napis, int lata)          //

W deklaracji tej funkcji skladowej w klasie, oraz w definicji
tej funkcji (juz ponizej). Dodane zostaly slowa "const",
za kazdym razem z tego samego powodu:
Otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*

------------------------------------------------------
int main()


-------------------------------------------------------
W funkcji zapamietaj dodane zostalo sprawdzenie
czy wskazni do stringu nie pokazuje czasem na adres 0 (NULL).
Gdyby tak bylo, to funkcja strcpy spowodowalaby blad pamieci.
Zatem najpierw to sprawdzamy, a jesli ta, to do tablicy nazwisko
wpisujemy 0 do zerowego elementu, co odpowiada pustemu stringowi

     if(napis)
        strcpy(nazwisko, napis) ;
     else
        nazwisko[0] = 0 ; // pusty string


************************************************************/
