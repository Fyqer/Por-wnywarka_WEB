//***************************************************
// Program z paragrafu   10.12.1 (str 284)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 



////////////////////////////////////////////////////////
// plik progr.c                                         ////
////////////////////////////////////////////////////////
#include <iostream>
using namespace std ;

// #include "osoba.h"                                        //
// Zamiast powyzszej dyrektywy include, cytuje tu cala klase
// (dla uproszczenia).

//////////////////   definicja klasy  /////////////////
class osoba {
     char nazwisko[80] ;                               //
     int wiek ;
public :                                               //
     void zapamietaj(const char * napis, int lata) ;         //
     //------------
     void wypisz()                                  //

     {
          cout << "\t" << nazwisko << " , lat : "
               << wiek << endl ;
     }
} ;
/////////////////// koniec definicji klasy //////////////
void osoba::zapamietaj(const char * napis, int lata)          //

{
     if(napis)
             strcpy(nazwisko, napis) ;
     else
             nazwisko[0] = 0 ; // pusty string

     wiek = lata ;
}


void prezentacja(osoba);                               //
/******************************************************/
int main()
{
     osoba kompozytor, autor ;                           //

     kompozytor.zapamietaj("Fryderyk Chopin", 36);
     autor.zapamietaj("Marcel Proust", 34);

     // wywolujemy funkcje, wysylajac obiekty
     prezentacja(kompozytor);                         //
     prezentacja(autor);                                 //
    
}
/********************************************************/
void prezentacja(osoba ktos)                           //
{
     cout << "Mam zaszczyt przedstawic panstwu, \n"
               "Oto we wlasnej osobie :" ;
     ktos.wypisz();                                    //
}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------
int main()


-------------------------------------------------------
Zmiany w klasie osoba (w funkcji zapamietaj) zostaly omowione przy
okazji omawiania przykladu 10_07_2.cpp

************************************************************/
