// ***************************************************
// Program z paragrafu   14.8.1 (str 363)
// ***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux) <--- !!!
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



// Uwaga: kompilator gcc 3.3.3 moze zrobic sobie optymalizacje
// Uniknie wtedy jednego uruchomienia konstruktora kopiujacego.
// Patrz wyjasnienia ponizej.


#include <iostream>
using namespace std ;

#include <cstring>
/////////////////////////////////////////////////////////
class kalibracja {
  float a, b  ;                    // wspolczynniki kalibracji
  char nazwa[80] ;                           // nazwa

public :
  // ------------------konstruktor
  kalibracja(float wsp_a, float wsp_b, const char * txt);

  // ----------------konstruktor kopiujacy
  kalibracja( kalibracja & wzor)  ;                //

  //  ---------------inne funkcje skladowe
  float energia (int kanal)
  {
    return( (a * kanal) + b ) ;
  }
  char * opis() {return( nazwa) ; }                  //

} ;
/////////////////////////////////////////////////////////
kalibracja::kalibracja(float wsp_a, float wsp_b,
		       const char * txt ) :  a(wsp_a), b(wsp_b)
{                                                        //
  if(txt) strcpy(nazwa, txt) ; //
}
/*******************************************************/
kalibracja::kalibracja(kalibracja & wzorzec)            //

{
  a = wzorzec.a ;
  b = wzorzec.b ;

  // zamiast :  strcpy(nazwa, wzorzec.nazwa) ;
  strcpy(nazwa,                                //
	 "-- To ja, konstruktor kopiujacy !!! --");

}
// ------------------------------------------------
void fun_pierwsza( kalibracja odebrana) ;
kalibracja fun_druga(void) ;
/*******************************************************/
int main()
{
  kalibracja kobalt(1.07, 2.4, "ORYGINALNA KOBALTOWA ");

  // Rozne warianty tego samego
  //kalibracja europ = kobalt ;                           //
  kalibracja  europ(kobalt) ;
  //kalibracja  europ = kalibracja(kobalt) ;
  //kalibracja  europ = kobalt ;

  cout << "O ktory kanal widma chodzi ? : " ;

  int kanal ;
  cin  >> kanal ;                                   //

  cout << "\nWedlug kalibracji kobalt, \nopisanej jako "

       << kobalt.opis()
       << "\nkanalowi nr " << kanal                //
       << " odpowiada energia "
       << kobalt.energia(kanal) << endl ;

  cout << "\nWedlug kalibracji europ, \nopisanej jako "
       << europ.opis()                //
       << "\nkanalowi nr " << kanal                //
       << " odpowiada energia "
       << europ.energia(kanal) << endl ;

  cout <<"\nDo funkcji pierwszej wysylam kalibracje "
       << kobalt.opis() << endl ;


  fun_pierwsza(kobalt) ;                               //

  cout << "\nTeraz wywolam funkcje druga, a jej"
    " rezultat\n"
    "podstawie do innej kalibracji \n" ;

  cout << "Obiekt chwilowy zwrocony jako "
    "rezultat funkcji \nma opis "
       << ( fun_druga() ).opis()                //
       << endl ;
}
/*******************************************************/
void fun_pierwsza( kalibracja odebrana)
{
  cout << "Natomiast w funkcji pierwszej "
    "odebralem te kalibracje\n"
    "\topisana jako "
       << odebrana.opis()                      //
       << endl ;
}
/*******************************************************/
kalibracja fun_druga(void)                         //
{
  kalibracja wewn(2, 1, "WEWNETRZNA") ;          //

  cout << "W funkcji fun_druga definiuje kalibracje"
    " i ma \nona opis : "
       << wewn.opis()
       << endl ;
  return wewn ;                                   // ((15))
}


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
     kalibracja(float wsp_a, float wsp_b, const char * txt);    // <------ dodane "const"

Zmiany te sa zarowno w deklaracji jak i w definicji tej funkcji.

Dodany jest przydomek const, bo otoz w mysl nowego standardu
"Ciag znakow bedacy stala doslowna" jest typu:  "const char tablica[n]"
(Gdzie n jest dlugoscia stringu + 1 na znak NULL) .
Jak widac, teraz znaki w takiej stalej doslownej maja byc const (niezmienialne)
wobec tego na taka tablice moze pokazywac tylko wskaznik, ktory te "niezmienialnosc"
zagwarantuje. Czyli wskaznik
     const char*

-----------------------------------------------------
          if(txt) strcpy(nazwa, txt) ; // dodane sprawdzenie if
Bo gdyby  wskaznik txt mial wartosc zero, to funkcja strcpy wywolaby  
blad pamieci
-----------------------------------------------------
int main()
------------------------------------------------------

    int i = 0 ;
     for(i = 0 ; i < 50 ; i++)

Definicja obiektu "i" jest wyjeta przed petle for, a to dlatego
ze z w drugiej peltli for ten obiekt "i" jest nadal uzywany.
W mysl standardu obiekt zdefiniowany tak jak poprzednio
- nie bylby widziany w drugiej petli. To dlatego wyjalem te definicjie
i postawilem linijke wyzej, nad pierwsza petla for.

-------------------------------------------------------
Uwaga: Kompilator ktory ma opcje optymalizacji
moze postapic sprytniej, niejako "na skroty".
Otoz widzac, ze w linijce ((15)) zwracamy obiekt lokalny
przez wartosc nie kopiuje go a nastepnie unicestwia,
lecz przedluza zycie tego obiektu, tak ze kaze mu byc
od razu kopia. Oszczedza pracy.

Jesli w Twoj kompilator jest tak sprytny, to na ekranie
zobaczysz:

Teraz wywolam funkcje druga, a jej rezultat
podstawie do innej kalibracji
W funkcji fun_druga definiuje kalibracje i ma
ona opis : WEWNETRZNA
Obiekt chwilowy zwrocony jako rezultat funkcji
ma opis WEWNETRZNA   <---------------- tutaj zmiana


Jak widzisz, tu jest slad, ze nie wystartowal konstruktor
kopiujacy, bo tekst opisu jest jota w jote, jak obiektu lokalnego.



VC++ zachowuje sie tutaj wedlug opisu z ksiazki


************************************************************/
